-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 15, 2024 at 04:51 AM
-- Server version: 10.11.7-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u951376346_himalaya`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_activity_photos`
--

CREATE TABLE `tbl_activity_photos` (
  `fld_aid` int(11) NOT NULL,
  `fld_ptid` int(11) NOT NULL COMMENT 'Photo type ID',
  `fld_uid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_did` int(11) NOT NULL,
  `fld_photo_path` varchar(255) NOT NULL,
  `fld_photo_file` varchar(255) NOT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_date` datetime NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_activity_photos`
--

INSERT INTO `tbl_activity_photos` (`fld_aid`, `fld_ptid`, `fld_uid`, `fld_pid`, `fld_state_id`, `fld_did`, `fld_photo_path`, `fld_photo_file`, `fld_lat`, `fld_long`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 4, 15, 1, 14, 1, 'activity/15/2024/04/01/', '1711976593.jpg', 22.64493840, 75.83331520, '2024-04-01 18:33:13', '2024-04-01 13:03:13', '2024-04-01 13:03:13'),
(2, 4, 17, 1, 14, 1, 'activity/17/2024/04/02/', '1712032691.jpg', 22.64494550, 75.83311250, '2024-04-02 10:08:11', '2024-04-02 04:38:11', '2024-04-02 04:38:11'),
(3, 4, 17, 1, 14, 1, 'activity/17/2024/04/02/', '1712052833.jpg', 22.64503600, 75.83319190, '2024-04-02 15:43:53', '2024-04-02 10:13:53', '2024-04-02 10:13:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendances`
--

CREATE TABLE `tbl_attendances` (
  `fld_aid` int(11) NOT NULL,
  `fld_uid` int(11) DEFAULT NULL,
  `fld_pid` int(11) DEFAULT NULL,
  `fld_state_id` int(11) NOT NULL,
  `fld_datetime` datetime DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_comment` varchar(255) DEFAULT NULL,
  `fld_photo_path` varchar(255) DEFAULT NULL,
  `fld_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_attendances`
--

INSERT INTO `tbl_attendances` (`fld_aid`, `fld_uid`, `fld_pid`, `fld_state_id`, `fld_datetime`, `fld_lat`, `fld_long`, `fld_comment`, `fld_photo_path`, `fld_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 15, 1, 14, '2024-04-01 15:53:27', 22.64498640, 75.83311680, NULL, 'attendance/15/2024/04/01/', '1711967007.jpg', '2024-04-01 10:23:27', '2024-04-01 10:23:27'),
(2, 15, 1, 14, '2024-04-02 10:03:09', 22.64489590, 75.83323330, NULL, 'attendance/15/2024/04/02/', '1712032389.jpg', '2024-04-02 04:33:09', '2024-04-02 04:33:09'),
(3, 16, 1, 14, '2024-04-02 10:03:47', 22.64490960, 75.83318570, NULL, 'attendance/16/2024/04/02/', '1712032427.jpg', '2024-04-02 04:33:47', '2024-04-02 04:33:47'),
(4, 17, 1, 14, '2024-04-02 10:06:14', 22.64492850, 75.83320310, NULL, 'attendance/17/2024/04/02/', '1712032574.jpg', '2024-04-02 04:36:14', '2024-04-02 04:36:14'),
(5, 17, 1, 14, '2024-04-05 12:47:19', 22.64503600, 75.83319190, NULL, 'attendance/17/2024/04/05/', '1712301438.jpg', '2024-04-05 07:17:19', '2024-04-05 07:17:19'),
(6, 15, 1, 14, '2024-04-05 12:47:56', 22.64489560, 75.83307750, NULL, 'attendance/15/2024/04/05/', '1712301476.jpg', '2024-04-05 07:17:56', '2024-04-05 07:17:56'),
(7, 15, 1, 14, '2024-04-06 16:38:58', 22.64489330, 75.83305400, NULL, 'attendance/15/2024/04/06/', '1712401738.jpg', '2024-04-06 11:08:58', '2024-04-06 11:08:58'),
(8, 15, 1, 14, '2024-04-07 13:28:36', 22.64490010, 75.83306860, NULL, 'attendance/15/2024/04/07/', '1712476716.jpg', '2024-04-07 07:58:36', '2024-04-07 07:58:36'),
(9, 15, 1, 14, '2024-04-08 09:29:14', 22.64481040, 75.83329000, NULL, 'attendance/15/2024/04/08/', '1712548754.jpg', '2024-04-08 03:59:14', '2024-04-08 03:59:14'),
(12, 17, 1, 14, '2024-04-10 15:06:42', 22.64490900, 75.83308740, NULL, 'attendance/17/2024/04/10/', '1712741802.jpg', '2024-04-10 09:36:42', '2024-04-10 09:36:42'),
(13, 15, 1, 14, '2024-04-10 18:43:43', 22.64488530, 75.83304930, NULL, 'attendance/15/2024/04/10/', '1712754823.jpg', '2024-04-10 13:13:43', '2024-04-10 13:13:43'),
(14, 15, 1, 14, '2024-04-11 11:20:30', 22.64488700, 75.83304990, NULL, 'attendance/15/2024/04/11/', '1712814630.jpg', '2024-04-11 05:50:30', '2024-04-11 05:50:30'),
(15, 15, 1, 14, '2024-04-12 12:51:35', 22.64491040, 75.83307930, NULL, 'attendance/15/2024/04/12/', '1712906495.jpg', '2024-04-12 07:21:35', '2024-04-12 07:21:35'),
(16, 17, 1, 14, '2024-04-12 13:00:54', 22.64493940, 75.83310000, NULL, 'attendance/17/2024/04/12/', '1712907054.jpg', '2024-04-12 07:30:54', '2024-04-12 07:30:54'),
(17, 15, 1, 14, '2024-04-13 13:11:05', 22.64485980, 75.83307080, NULL, 'attendance/15/2024/04/13/', '1712994065.jpg', '2024-04-13 07:41:05', '2024-04-13 07:41:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_clients`
--

CREATE TABLE `tbl_clients` (
  `fld_cid` int(11) NOT NULL,
  `fld_name` varchar(255) NOT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_clients`
--

INSERT INTO `tbl_clients` (`fld_cid`, `fld_name`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 'Wilmar', 1, '2024-02-25 17:31:02', '2024-02-27 15:10:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consumers`
--

CREATE TABLE `tbl_consumers` (
  `fld_cid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_did` int(11) NOT NULL COMMENT 'District ID',
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_uid` int(11) NOT NULL,
  `fld_name` varchar(255) NOT NULL,
  `fld_number` varchar(255) NOT NULL,
  `fld_remark` varchar(200) DEFAULT NULL,
  `fld_remark2` varchar(200) DEFAULT NULL,
  `fld_remark3` varchar(200) DEFAULT NULL,
  `fld_village_id` varchar(255) NOT NULL,
  `fld_tehsil_id` varchar(255) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_consumers`
--

INSERT INTO `tbl_consumers` (`fld_cid`, `fld_mobile_id`, `fld_pid`, `fld_did`, `fld_state_id`, `fld_uid`, `fld_name`, `fld_number`, `fld_remark`, `fld_remark2`, `fld_remark3`, `fld_village_id`, `fld_tehsil_id`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_c21jHn1m', 1, 1, 14, 15, 'test', '9522665555', NULL, NULL, NULL, '1', '1', 22.64495560, 75.83331070, '2024-04-01 13:03:50', '2024-04-01 13:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consumer_sales`
--

CREATE TABLE `tbl_consumer_sales` (
  `fld_csid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL COMMENT 'mobile db order id',
  `fld_cid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_remark` varchar(500) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_bill_photo_path` varchar(255) DEFAULT NULL,
  `fld_bill_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_consumer_sales`
--

INSERT INTO `tbl_consumer_sales` (`fld_csid`, `fld_mobile_id`, `fld_cid`, `fld_uid`, `fld_pid`, `fld_total`, `fld_date`, `fld_remark`, `fld_lat`, `fld_long`, `fld_bill_photo_path`, `fld_bill_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_Gl4hZy7J', 1, 15, 1, 40.00, '2024-04-01', 'test', 22.64500450, 75.83326100, 'consumers/15/bill/2024/04', '1711976649.jpg', '2024-04-01 13:04:09', '2024-04-11 18:45:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_consumer_sales_items`
--

CREATE TABLE `tbl_consumer_sales_items` (
  `fld_csiid` int(11) NOT NULL,
  `fld_csid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) DEFAULT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_product` varchar(255) NOT NULL,
  `fld_qty` int(11) NOT NULL,
  `fld_price` decimal(10,2) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_consumer_sales_items`
--

INSERT INTO `tbl_consumer_sales_items` (`fld_csiid`, `fld_csid`, `fld_mobile_id`, `fld_pid`, `fld_product`, `fld_qty`, `fld_price`, `fld_total`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, '15_Gl4hZy7J', 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 5, 8.00, 40.00, '2024-04-01', '2024-04-01 13:04:09', '2024-04-01 13:04:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_consumers`
--

CREATE TABLE `tbl_mandi_consumers` (
  `fld_cid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_district_id` int(11) NOT NULL COMMENT 'District ID',
  `fld_town_id` int(11) NOT NULL COMMENT 'Town ID',
  `fld_mandi_id` int(11) DEFAULT NULL COMMENT 'Mandi ID',
  `fld_wsid` int(11) NOT NULL COMMENT 'Wholesaler ID',
  `fld_name` varchar(255) NOT NULL,
  `fld_number` varchar(255) NOT NULL,
  `fld_village` varchar(100) DEFAULT NULL COMMENT 'Village',
  `fld_remark` varchar(200) DEFAULT NULL,
  `fld_remark2` varchar(200) DEFAULT NULL,
  `fld_remark3` varchar(200) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_consumers`
--

INSERT INTO `tbl_mandi_consumers` (`fld_cid`, `fld_mobile_id`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_mandi_id`, `fld_wsid`, `fld_name`, `fld_number`, `fld_village`, `fld_remark`, `fld_remark2`, `fld_remark3`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '17_sVIHuicF', 1, 17, 14, 1, 1, 1, 1, 'test', '8899665777', 'rau', NULL, NULL, NULL, 22.64489150, 75.83306730, '2024-04-02 10:13:10', '2024-04-02 10:13:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_consumer_sales`
--

CREATE TABLE `tbl_mandi_consumer_sales` (
  `fld_mcsid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL COMMENT 'mobile db order id',
  `fld_mcid` int(11) NOT NULL COMMENT 'Mandi Consumer ID',
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_remark` varchar(500) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_bill_photo_path` varchar(255) DEFAULT NULL,
  `fld_bill_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_consumer_sales`
--

INSERT INTO `tbl_mandi_consumer_sales` (`fld_mcsid`, `fld_mobile_id`, `fld_mcid`, `fld_uid`, `fld_pid`, `fld_total`, `fld_date`, `fld_remark`, `fld_lat`, `fld_long`, `fld_bill_photo_path`, `fld_bill_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '17_U47lnjGA', 1, 17, 1, 40.00, '2024-04-02', NULL, 22.64488780, 75.83307040, 'mandi/consumers/17/bill/2024/04', '1712052813.jpg', '2024-04-02 10:13:33', '2024-04-02 10:13:33'),
(2, '17_nTGO9VLP', 1, 17, 1, 838.00, '2024-04-12', 'cgj g m call karle thi na lekin i', 22.64488250, 75.83307810, 'mandi/consumers/17/bill/2024/04', '1712907413.jpg', '2024-04-12 07:36:53', '2024-04-12 07:36:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_consumer_sales_items`
--

CREATE TABLE `tbl_mandi_consumer_sales_items` (
  `fld_mcsiid` int(11) NOT NULL,
  `fld_mcsid` int(11) NOT NULL COMMENT 'Mandi Consumer Sales ID',
  `fld_mobile_id` varchar(20) DEFAULT NULL,
  `fld_pid` int(11) NOT NULL COMMENT 'Product ID',
  `fld_product` varchar(255) NOT NULL,
  `fld_qty` int(11) NOT NULL,
  `fld_price` decimal(10,2) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_consumer_sales_items`
--

INSERT INTO `tbl_mandi_consumer_sales_items` (`fld_mcsiid`, `fld_mcsid`, `fld_mobile_id`, `fld_pid`, `fld_product`, `fld_qty`, `fld_price`, `fld_total`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, '17_U47lnjGA', 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 8, 5.00, 40.00, '2024-04-02', '2024-04-02 10:13:33', '2024-04-02 10:13:33'),
(2, 2, '17_nTGO9VLP', 8, 'FORTUNE PURE GN OIL 12 X 1 LT PCH', 8, 8.00, 64.00, '2024-04-12', '2024-04-12 07:36:53', '2024-04-12 07:36:53'),
(3, 2, '17_nTGO9VLP', 9, 'FORTUNE REGULAR CHAKKI ATTA 6X5KG W2', 9, 86.00, 774.00, '2024-04-12', '2024-04-12 07:36:53', '2024-04-12 07:36:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_retailers`
--

CREATE TABLE `tbl_mandi_retailers` (
  `fld_rid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_district_id` int(11) NOT NULL COMMENT 'District ID',
  `fld_town_id` int(11) DEFAULT NULL COMMENT 'Town ID',
  `fld_mandi_id` int(11) NOT NULL COMMENT 'Mandi',
  `fld_wsid` int(11) NOT NULL COMMENT 'Wholesaler ID',
  `fld_store_name` varchar(255) NOT NULL,
  `fld_owner_name` varchar(255) NOT NULL,
  `fld_number` varchar(255) NOT NULL,
  `fld_village` varchar(100) DEFAULT NULL,
  `fld_type` tinyint(4) NOT NULL COMMENT '(1 = Retailer / 2 = Wholesaler)',
  `fld_comments_1` varchar(255) DEFAULT NULL,
  `fld_comments_2` varchar(255) DEFAULT NULL,
  `fld_comments_3` varchar(255) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_photo_path` varchar(255) DEFAULT NULL,
  `fld_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_retailers`
--

INSERT INTO `tbl_mandi_retailers` (`fld_rid`, `fld_mobile_id`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_mandi_id`, `fld_wsid`, `fld_store_name`, `fld_owner_name`, `fld_number`, `fld_village`, `fld_type`, `fld_comments_1`, `fld_comments_2`, `fld_comments_3`, `fld_lat`, `fld_long`, `fld_photo_path`, `fld_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '17_sCyctXPO', 1, 17, 14, 1, 1, 1, 1, 'test', 'test', '7896523147', 'rau', 1, NULL, NULL, NULL, 22.64488430, 75.83306530, 'mandi/retailers/17/store/2024/04', '1712052738.jpg', '2024-04-02 10:12:18', '2024-04-02 10:12:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_retail_sales`
--

CREATE TABLE `tbl_mandi_retail_sales` (
  `fld_rsid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL COMMENT 'mobile db order id',
  `fld_mrid` int(11) NOT NULL COMMENT 'Mandi Retailer ID',
  `fld_uid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_remark` varchar(500) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_bill_photo_path` varchar(255) DEFAULT NULL,
  `fld_bill_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_retail_sales`
--

INSERT INTO `tbl_mandi_retail_sales` (`fld_rsid`, `fld_mobile_id`, `fld_mrid`, `fld_uid`, `fld_pid`, `fld_total`, `fld_date`, `fld_remark`, `fld_lat`, `fld_long`, `fld_bill_photo_path`, `fld_bill_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '17_sXbaaZOv', 1, 17, 1, 64.00, '2024-04-02', NULL, 22.64489380, 75.83306690, 'mandi/retailers/17/bill/2024/04', '1712052760.jpg', '2024-04-02 10:12:40', '2024-04-02 10:12:40'),
(2, '17_fparIUQc', 1, 17, 1, 30.00, '2024-04-12', 'dghu', 22.64490980, 75.83306450, 'mandi/retailers/17/bill/2024/04', '1712907086.jpg', '2024-04-12 07:31:26', '2024-04-12 07:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_retail_sales_items`
--

CREATE TABLE `tbl_mandi_retail_sales_items` (
  `fld_mrsiid` int(11) NOT NULL,
  `fld_mrsid` int(11) NOT NULL COMMENT 'Mandi Retailer Sales ID',
  `fld_mobile_id` varchar(20) DEFAULT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_product` varchar(255) NOT NULL,
  `fld_qty` int(11) NOT NULL,
  `fld_price` decimal(10,2) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_retail_sales_items`
--

INSERT INTO `tbl_mandi_retail_sales_items` (`fld_mrsiid`, `fld_mrsid`, `fld_mobile_id`, `fld_pid`, `fld_product`, `fld_qty`, `fld_price`, `fld_total`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, '17_sXbaaZOv', 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 8, 8.00, 64.00, '2024-04-02', '2024-04-02 10:12:40', '2024-04-02 10:12:40'),
(2, 2, '17_fparIUQc', 9, 'FORTUNE REGULAR CHAKKI ATTA 6X5KG W2', 5, 6.00, 30.00, '2024-04-12', '2024-04-12 07:31:26', '2024-04-12 07:31:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_routes`
--

CREATE TABLE `tbl_mandi_routes` (
  `fld_rpid` int(11) NOT NULL,
  `fld_rphid` int(11) DEFAULT NULL,
  `fld_pid` int(11) DEFAULT NULL COMMENT 'Project ID',
  `fld_uid` int(11) DEFAULT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_town_id` int(11) DEFAULT NULL,
  `fld_mandi_id` int(11) DEFAULT NULL,
  `fld_wsid` int(11) NOT NULL COMMENT 'Wholesaler ID',
  `fld_user` varchar(255) DEFAULT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mandi_routes`
--

INSERT INTO `tbl_mandi_routes` (`fld_rpid`, `fld_rphid`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_mandi_id`, `fld_wsid`, `fld_user`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 0, 1, 17, 14, 1, 1, 1, 1, 'adanivan1', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:30'),
(2, 0, 1, 17, 14, 1, 1, 2, 2, 'adanivan1', '2024-03-21', '2024-03-20 08:33:00', '2024-03-26 11:32:18'),
(3, 0, 1, 17, 14, 1, 1, 3, 3, 'adanivan1', '2024-03-22', '2024-03-20 08:33:00', '2024-03-26 11:32:22'),
(4, 0, 1, 17, 14, 1, 2, 4, 1, 'adanivan1', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(5, 0, 1, 17, 14, 1, 2, 5, 2, 'adanivan1', '2024-03-24', '2024-03-20 08:33:00', '2024-03-26 11:32:28'),
(6, 0, 1, 17, 14, 2, 3, 6, 3, 'adanivan2', '2024-03-20', '2024-03-20 08:33:00', '2024-03-26 11:32:31'),
(7, 0, 1, 17, 14, 2, 4, 7, 1, 'adanivan2', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(8, 0, 1, 17, 14, 2, 5, 8, 1, 'adanivan2', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(9, 0, 1, 17, 14, 2, 6, 9, 1, 'adanivan2', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(10, 0, 1, 17, 14, 2, 6, 10, 1, 'adanivan2', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(11, 0, 1, 17, 14, 3, 7, 11, 1, 'adanivan3', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(12, 0, 1, 17, 14, 3, 7, 12, 1, 'adanivan3', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(13, 0, 1, 17, 14, 3, 8, 13, 1, 'adanivan3', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(14, 0, 1, 17, 14, 3, 8, 14, 1, 'adanivan3', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(15, 0, 1, 17, 14, 3, 8, 15, 1, 'adanivan3', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(16, 0, 1, 17, 14, 4, 9, 16, 1, 'adanivan4', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(17, 0, 1, 17, 14, 4, 9, 17, 1, 'adanivan4', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(18, 0, 1, 17, 14, 4, 10, 18, 1, 'adanivan4', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(19, 0, 1, 17, 14, 4, 10, 19, 1, 'adanivan4', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(20, 0, 1, 17, 14, 4, 11, 20, 1, 'adanivan4', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(21, 0, 1, 17, 14, 5, 12, 21, 1, 'adanivan5', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(22, 0, 1, 17, 14, 5, 13, 22, 1, 'adanivan5', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(23, 0, 1, 17, 14, 5, 14, 23, 1, 'adanivan5', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(24, 0, 1, 17, 14, 5, 15, 24, 1, 'adanivan5', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(25, 0, 1, 17, 14, 5, 16, 25, 1, 'adanivan5', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(26, 0, 1, 17, 14, 6, 17, 26, 1, 'adanivan6', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(27, 0, 1, 17, 14, 6, 18, 27, 1, 'adanivan6', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(28, 0, 1, 17, 14, 6, 18, 28, 1, 'adanivan6', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(29, 0, 1, 17, 14, 6, 18, 29, 1, 'adanivan6', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(30, 0, 1, 17, 14, 7, 19, 30, 1, 'adanivan7', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(31, 0, 1, 17, 14, 7, 19, 31, 1, 'adanivan7', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(32, 0, 1, 17, 14, 7, 20, 32, 1, 'adanivan7', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(33, 0, 1, 17, 14, 7, 20, 33, 1, 'adanivan7', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(34, 0, 1, 17, 14, 8, 21, 34, 1, 'adanivan8', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(35, 0, 1, 17, 14, 8, 21, 35, 1, 'adanivan8', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(36, 0, 1, 17, 14, 8, 21, 36, 1, 'adanivan8', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(37, 0, 1, 17, 14, 8, 21, 37, 1, 'adanivan8', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(38, 0, 1, 17, 14, 8, 21, 38, 1, 'adanivan8', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(39, 0, 1, 17, 14, 9, 22, 39, 1, 'adanivan9', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(40, 0, 1, 17, 14, 9, 22, 40, 1, 'adanivan9', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(41, 0, 1, 17, 14, 9, 22, 41, 1, 'adanivan9', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(42, 0, 1, 17, 14, 9, 22, 42, 1, 'adanivan9', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(43, 0, 1, 17, 14, 9, 22, 43, 1, 'adanivan9', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(44, 0, 1, 17, 14, 10, 23, 44, 1, 'adanivan10', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(45, 0, 1, 17, 14, 10, 23, 45, 1, 'adanivan10', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(46, 0, 1, 17, 14, 10, 24, 46, 1, 'adanivan10', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(47, 0, 1, 17, 14, 10, 25, 47, 1, 'adanivan10', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(48, 0, 1, 17, 14, 10, 25, 48, 1, 'adanivan10', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(49, 0, 1, 17, 14, 11, 26, 49, 1, 'adanivan11', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(50, 0, 1, 17, 14, 11, 27, 50, 1, 'adanivan11', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(51, 0, 1, 17, 14, 11, 28, 51, 1, 'adanivan11', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(52, 0, 1, 17, 14, 11, 29, 52, 1, 'adanivan11', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(53, 0, 1, 17, 14, 12, 30, 53, 1, 'adanivan12', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(54, 0, 1, 17, 14, 12, 30, 54, 1, 'adanivan12', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(55, 0, 1, 17, 14, 12, 30, 55, 1, 'adanivan12', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(56, 0, 1, 17, 14, 12, 30, 56, 1, 'adanivan12', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(57, 0, 1, 17, 14, 13, 31, 57, 1, 'adanivan12', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(58, 0, 1, 17, 14, 14, 32, 58, 1, 'adanivan13', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(59, 0, 1, 17, 14, 14, 32, 59, 1, 'adanivan13', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(60, 0, 1, 17, 14, 14, 33, 60, 1, 'adanivan13', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(61, 0, 1, 17, 14, 14, 33, 61, 1, 'adanivan13', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(62, 0, 1, 17, 14, 14, 33, 62, 1, 'adanivan13', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(63, 0, 1, 17, 14, 1, 1, 1, 1, 'vandemo', '2024-03-20', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(64, 0, 1, 17, 14, 1, 1, 2, 1, 'vandemo', '2024-03-21', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(65, 0, 1, 17, 14, 1, 1, 3, 1, 'vandemo', '2024-03-22', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(66, 0, 1, 17, 14, 1, 2, 4, 1, 'vandemo', '2024-03-23', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(67, 0, 1, 17, 14, 1, 2, 5, 1, 'vandemo', '2024-03-24', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(68, NULL, 1, 17, 14, 1, 1, 63, 1, 'adanivan1', '2024-03-20', '2024-03-20 11:05:00', '2024-03-25 12:14:50'),
(69, NULL, 1, 17, 14, 6, 17, 64, 1, 'adanivan6', '2024-03-21', '2024-03-20 11:17:01', '2024-03-25 12:14:50'),
(70, NULL, 1, 17, 14, 6, 17, 65, 1, 'adanivan6', '2024-03-21', '2024-03-21 04:25:07', '2024-03-25 12:14:50'),
(71, NULL, 1, 17, 14, 6, 17, 65, 1, 'adanivan6', '2024-03-21', '2024-03-21 04:42:01', '2024-03-25 12:14:50'),
(72, NULL, 1, 17, 14, 12, 30, 66, 1, 'adanivan12', '2024-03-20', '2024-03-21 07:23:44', '2024-03-25 12:14:50'),
(73, NULL, 1, 17, 14, 2, 4, 67, 1, 'adanivan2', '2024-03-21', '2024-03-21 09:26:51', '2024-03-25 12:14:50'),
(74, NULL, 1, 17, 14, 2, 4, 67, 1, 'adanivan2', '2024-03-21', '2024-03-21 09:31:58', '2024-03-25 12:14:50'),
(75, NULL, 1, 17, 14, 1, 1, 68, 1, 'adanivan1', '2024-03-21', '2024-03-21 11:22:17', '2024-03-25 12:14:50'),
(76, NULL, 1, 17, 14, 1, 3, 69, 1, 'adanivan5', '2024-03-01', '2024-03-21 14:12:10', '2024-03-25 12:14:50'),
(77, NULL, 1, 17, 14, 4, 10, 70, 1, 'adanivan4', '2024-03-22', '2024-03-22 09:53:50', '2024-03-25 12:14:50'),
(78, NULL, 1, 17, 14, 2, 5, 71, 1, 'adanivan2', '2024-03-22', '2024-03-22 10:19:28', '2024-03-25 12:14:50'),
(79, NULL, 1, 17, 14, 2, 5, 71, 1, 'adanivan2', '2024-03-22', '2024-03-22 10:47:29', '2024-03-25 12:14:50'),
(80, NULL, 1, 17, 14, 3, 8, 72, 1, 'adanivan3', '2024-03-22', '2024-03-22 11:15:47', '2024-03-25 12:14:50'),
(81, NULL, 1, 17, 14, 2, 5, 73, 1, 'adanivan2', '2024-03-22', '2024-03-22 11:19:25', '2024-03-25 12:14:50'),
(82, NULL, 1, 17, 14, 3, 8, 74, 1, 'adanivan3', '2024-03-22', '2024-03-22 11:23:14', '2024-03-25 12:14:50'),
(83, NULL, 1, 17, 14, 3, 8, 75, 1, 'adanivan3', '2024-03-22', '2024-03-22 12:55:20', '2024-03-25 12:14:50'),
(84, NULL, 1, 17, 14, 2, 6, 76, 1, 'adanivan2', '2024-03-23', '2024-03-23 03:56:00', '2024-03-25 12:14:50'),
(85, NULL, 1, 17, 14, 11, 28, 77, 1, 'adanivan11', '2024-03-23', '2024-03-23 05:28:42', '2024-03-25 12:14:50'),
(86, NULL, 1, 17, 14, 11, 28, 78, 1, 'adanivan11', '2024-03-23', '2024-03-23 06:07:24', '2024-03-25 12:14:50'),
(87, NULL, 1, 17, 14, 11, 28, 79, 1, 'adanivan11', '2024-03-23', '2024-03-23 06:18:18', '2024-03-25 12:14:50'),
(88, NULL, 1, 17, 14, 11, 28, 79, 1, 'adanivan11', '2024-03-23', '2024-03-23 06:20:56', '2024-03-25 12:14:50'),
(89, NULL, 1, 17, 14, 11, 28, 79, 1, 'vandemo', '2024-03-23', '2024-03-23 06:31:40', '2024-03-25 12:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_routes_historys`
--

CREATE TABLE `tbl_mandi_routes_historys` (
  `fld_mhrid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_remark` varchar(100) DEFAULT NULL COMMENT 'Remark',
  `fld_path` varchar(100) NOT NULL COMMENT 'XLS File Path',
  `fld_file` varchar(100) NOT NULL COMMENT 'File Name',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mandi_wholesalers`
--

CREATE TABLE `tbl_mandi_wholesalers` (
  `fld_wsid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_state_id` int(11) NOT NULL,
  `fld_district_id` int(11) NOT NULL,
  `fld_town_id` int(11) NOT NULL,
  `fld_mandi_id` int(11) NOT NULL,
  `fld_wholesaler` varchar(100) NOT NULL,
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_mandi_wholesalers`
--

INSERT INTO `tbl_mandi_wholesalers` (`fld_wsid`, `fld_pid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_mandi_id`, `fld_wholesaler`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 14, 1, 1, 1, 'Gupta Stores', '2024-04-02 10:06:08', '2024-04-02 10:06:35'),
(2, 1, 14, 1, 1, 2, 'Harish Stores', '2024-04-02 10:06:08', '2024-04-02 10:06:35'),
(3, 1, 14, 1, 1, 3, 'Anand Stores', '2024-04-02 10:06:08', '2024-04-02 10:06:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mela`
--

CREATE TABLE `tbl_mela` (
  `fld_mid` int(11) NOT NULL,
  `fld_mhid` int(11) DEFAULT NULL COMMENT 'Mela History ID',
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_location` varchar(50) NOT NULL COMMENT 'Location Name',
  `fld_address` varchar(100) NOT NULL COMMENT 'Address',
  `fld_village_id` int(11) NOT NULL COMMENT 'Village ID',
  `fld_district_id` int(11) NOT NULL COMMENT 'District ID',
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_remark` text DEFAULT NULL,
  `fld_lat` varchar(20) NOT NULL,
  `fld_long` varchar(20) NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mela`
--

INSERT INTO `tbl_mela` (`fld_mid`, `fld_mhid`, `fld_uid`, `fld_pid`, `fld_location`, `fld_address`, `fld_village_id`, `fld_district_id`, `fld_state_id`, `fld_remark`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, NULL, 16, 1, 'rau', 'silicon city', 1, 1, 14, NULL, '22.6449034', '75.8331937', '2024-04-02 04:34:10', '2024-04-02 04:34:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mela_consumers`
--

CREATE TABLE `tbl_mela_consumers` (
  `fld_mcid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_mid` int(11) NOT NULL COMMENT 'Mela ID',
  `fld_name` varchar(50) NOT NULL,
  `fld_phone` varchar(10) NOT NULL,
  `fld_village` varchar(50) NOT NULL,
  `fld_remark` varchar(200) DEFAULT NULL,
  `fld_lat` varchar(20) NOT NULL,
  `fld_long` varchar(20) NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mela_consumers`
--

INSERT INTO `tbl_mela_consumers` (`fld_mcid`, `fld_uid`, `fld_pid`, `fld_mid`, `fld_name`, `fld_phone`, `fld_village`, `fld_remark`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 16, 1, 1, 'test consumer', '9966325807', 'rau', NULL, '22.6449276', '75.8331878', '2024-04-02 04:34:52', '2024-04-02 04:34:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mela_images`
--

CREATE TABLE `tbl_mela_images` (
  `fld_miid` int(11) NOT NULL,
  `fld_mid` int(11) NOT NULL COMMENT 'Mela ID',
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_image_type` int(11) NOT NULL COMMENT 'Image Type',
  `fld_path` varchar(100) NOT NULL,
  `fld_image` varchar(20) NOT NULL,
  `fld_lat` varchar(20) NOT NULL,
  `fld_long` varchar(20) NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mela_images`
--

INSERT INTO `tbl_mela_images` (`fld_miid`, `fld_mid`, `fld_uid`, `fld_image_type`, `fld_path`, `fld_image`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 16, 9, 'mela/16/2024/04', '1712032518.jpg', '22.6449169', '75.8331949', '2024-04-02 04:35:18', '2024-04-02 04:35:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mela_routes`
--

CREATE TABLE `tbl_mela_routes` (
  `fld_rpid` int(11) NOT NULL,
  `fld_rphid` int(11) DEFAULT 0,
  `fld_pid` int(11) DEFAULT NULL,
  `fld_uid` int(11) DEFAULT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_village_id` int(11) DEFAULT NULL,
  `fld_user` varchar(255) DEFAULT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mela_routes`
--

INSERT INTO `tbl_mela_routes` (`fld_rpid`, `fld_rphid`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_village_id`, `fld_user`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 0, 1, 16, 14, 1, 1, 'adanivan1', '2024-03-20', '2024-03-20 08:33:00', '2024-03-28 17:50:10'),
(2, 0, 1, 16, 14, 1, 2, 'adanivan1', '2024-03-21', '2024-03-20 08:33:00', '2024-03-28 17:50:14'),
(3, 0, 1, 2, 14, 1, 3, 'adanivan1', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(4, 0, 1, 2, 14, 1, 4, 'adanivan1', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(5, 0, 1, 2, 14, 1, 5, 'adanivan1', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(6, 0, 1, 3, 14, 2, 6, 'adanivan2', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(7, 0, 1, 3, 14, 2, 7, 'adanivan2', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(8, 0, 1, 3, 14, 2, 8, 'adanivan2', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(9, 0, 1, 3, 14, 2, 9, 'adanivan2', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(10, 0, 1, 3, 14, 2, 10, 'adanivan2', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(11, 0, 1, 4, 14, 3, 11, 'adanivan3', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(12, 0, 1, 4, 14, 3, 12, 'adanivan3', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(13, 0, 1, 4, 14, 3, 13, 'adanivan3', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(14, 0, 1, 4, 14, 3, 14, 'adanivan3', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(15, 0, 1, 4, 14, 3, 15, 'adanivan3', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(16, 0, 1, 5, 14, 4, 16, 'adanivan4', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(17, 0, 1, 5, 14, 4, 17, 'adanivan4', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(18, 0, 1, 5, 14, 4, 18, 'adanivan4', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(19, 0, 1, 5, 14, 4, 19, 'adanivan4', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(20, 0, 1, 5, 14, 4, 20, 'adanivan4', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(21, 0, 1, 6, 14, 5, 21, 'adanivan5', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(22, 0, 1, 6, 14, 5, 22, 'adanivan5', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(23, 0, 1, 6, 14, 5, 23, 'adanivan5', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(24, 0, 1, 6, 14, 5, 24, 'adanivan5', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(25, 0, 1, 6, 14, 5, 25, 'adanivan5', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(26, 0, 1, 7, 14, 6, 26, 'adanivan6', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(27, 0, 1, 7, 14, 6, 27, 'adanivan6', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(28, 0, 1, 7, 14, 6, 28, 'adanivan6', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(29, 0, 1, 7, 14, 6, 29, 'adanivan6', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(30, 0, 1, 8, 14, 7, 30, 'adanivan7', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(31, 0, 1, 8, 14, 7, 31, 'adanivan7', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(32, 0, 1, 8, 14, 7, 32, 'adanivan7', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(33, 0, 1, 8, 14, 7, 33, 'adanivan7', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(34, 0, 1, 9, 14, 8, 34, 'adanivan8', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(35, 0, 1, 9, 14, 8, 35, 'adanivan8', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(36, 0, 1, 9, 14, 8, 36, 'adanivan8', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(37, 0, 1, 9, 14, 8, 37, 'adanivan8', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(38, 0, 1, 9, 14, 8, 38, 'adanivan8', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(39, 0, 1, 10, 14, 9, 39, 'adanivan9', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(40, 0, 1, 10, 14, 9, 40, 'adanivan9', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(41, 0, 1, 10, 14, 9, 41, 'adanivan9', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(42, 0, 1, 10, 14, 9, 42, 'adanivan9', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(43, 0, 1, 10, 14, 9, 43, 'adanivan9', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(44, 0, 1, 11, 14, 10, 44, 'adanivan10', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(45, 0, 1, 11, 14, 10, 45, 'adanivan10', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(46, 0, 1, 11, 14, 10, 46, 'adanivan10', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(47, 0, 1, 11, 14, 10, 47, 'adanivan10', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(48, 0, 1, 11, 14, 10, 48, 'adanivan10', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(49, 0, 1, 12, 14, 11, 49, 'adanivan11', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(50, 0, 1, 12, 14, 11, 50, 'adanivan11', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(51, 0, 1, 12, 14, 11, 51, 'adanivan11', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(52, 0, 1, 12, 14, 11, 52, 'adanivan11', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(53, 0, 1, 13, 14, 12, 53, 'adanivan12', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(54, 0, 1, 13, 14, 12, 54, 'adanivan12', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(55, 0, 1, 13, 14, 12, 55, 'adanivan12', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(56, 0, 1, 13, 14, 12, 56, 'adanivan12', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(57, 0, 1, 13, 14, 13, 57, 'adanivan12', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(58, 0, 1, 14, 14, 14, 58, 'adanivan13', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(59, 0, 1, 14, 14, 14, 59, 'adanivan13', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(60, 0, 1, 14, 14, 14, 60, 'adanivan13', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(61, 0, 1, 14, 14, 14, 61, 'adanivan13', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(62, 0, 1, 14, 14, 14, 62, 'adanivan13', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(63, 0, 1, 15, 14, 1, 1, 'vandemo', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(64, 0, 1, 15, 14, 1, 2, 'vandemo', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(65, 0, 1, 15, 14, 1, 3, 'vandemo', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(66, 0, 1, 15, 14, 1, 4, 'vandemo', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(67, 0, 1, 15, 14, 1, 5, 'vandemo', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(68, NULL, 1, 2, 14, 1, 63, 'adanivan1', '2024-03-20', '2024-03-20 11:05:00', '2024-03-20 11:05:00'),
(69, NULL, 1, 7, 14, 6, 64, 'adanivan6', '2024-03-21', '2024-03-20 11:17:01', '2024-03-20 11:17:01'),
(70, NULL, 1, 7, 14, 6, 65, 'adanivan6', '2024-03-21', '2024-03-21 04:25:07', '2024-03-21 04:25:07'),
(71, NULL, 1, 7, 14, 6, 65, 'adanivan6', '2024-03-21', '2024-03-21 04:42:01', '2024-03-21 04:42:01'),
(72, NULL, 1, 13, 14, 12, 66, 'adanivan12', '2024-03-20', '2024-03-21 07:23:44', '2024-03-21 07:23:44'),
(73, NULL, 1, 3, 14, 2, 67, 'adanivan2', '2024-03-21', '2024-03-21 09:26:51', '2024-03-21 09:26:51'),
(74, NULL, 1, 3, 14, 2, 67, 'adanivan2', '2024-03-21', '2024-03-21 09:31:58', '2024-03-21 09:31:58'),
(75, NULL, 1, 2, 14, 1, 68, 'adanivan1', '2024-03-21', '2024-03-21 11:22:17', '2024-03-21 11:22:17'),
(76, NULL, 1, 6, 14, 1, 69, 'adanivan5', '2024-03-01', '2024-03-21 14:12:10', '2024-03-21 14:12:10'),
(77, NULL, 1, 5, 14, 4, 70, 'adanivan4', '2024-03-22', '2024-03-22 09:53:50', '2024-03-22 09:53:50'),
(78, NULL, 1, 3, 14, 2, 71, 'adanivan2', '2024-03-22', '2024-03-22 10:19:28', '2024-03-22 10:19:28'),
(79, NULL, 1, 3, 14, 2, 71, 'adanivan2', '2024-03-22', '2024-03-22 10:47:29', '2024-03-22 10:47:29'),
(80, NULL, 1, 4, 14, 3, 72, 'adanivan3', '2024-03-22', '2024-03-22 11:15:47', '2024-03-22 11:15:47'),
(81, NULL, 1, 3, 14, 2, 73, 'adanivan2', '2024-03-22', '2024-03-22 11:19:25', '2024-03-22 11:19:25'),
(82, NULL, 1, 4, 14, 3, 74, 'adanivan3', '2024-03-22', '2024-03-22 11:23:14', '2024-03-22 11:23:14'),
(83, NULL, 1, 4, 14, 3, 75, 'adanivan3', '2024-03-22', '2024-03-22 12:55:20', '2024-03-22 12:55:20'),
(84, NULL, 1, 3, 14, 2, 76, 'adanivan2', '2024-03-23', '2024-03-23 03:56:00', '2024-03-23 03:56:00'),
(85, NULL, 1, 12, 14, 11, 77, 'adanivan11', '2024-03-23', '2024-03-23 05:28:42', '2024-03-23 05:28:42'),
(86, NULL, 1, 12, 14, 11, 78, 'adanivan11', '2024-03-23', '2024-03-23 06:07:24', '2024-03-23 06:07:24'),
(87, NULL, 1, 12, 14, 11, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:18:18', '2024-03-23 06:18:18'),
(88, NULL, 1, 12, 14, 11, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:20:56', '2024-03-23 06:20:56'),
(89, NULL, 1, 12, 14, 11, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:31:40', '2024-03-23 06:31:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mela_routes_historys`
--

CREATE TABLE `tbl_mela_routes_historys` (
  `fld_mhid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_remark` varchar(100) DEFAULT NULL COMMENT 'Remark',
  `fld_path` varchar(100) NOT NULL COMMENT 'XLS File Path',
  `fld_file` varchar(100) NOT NULL COMMENT 'File Name',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `fld_pid` int(11) NOT NULL,
  `fld_p_id` int(11) NOT NULL COMMENT 'Project ID',
  `fld_name` varchar(255) NOT NULL,
  `fld_sku` varchar(255) DEFAULT NULL,
  `fld_display_order` int(11) DEFAULT 0,
  `fld_mrp` decimal(10,2) DEFAULT 0.00,
  `fld_cost_price` decimal(10,2) DEFAULT 0.00,
  `fld_selling_price` decimal(10,2) DEFAULT 0.00,
  `fld_type` tinyint(4) DEFAULT 1,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`fld_pid`, `fld_p_id`, `fld_name`, `fld_sku`, `fld_display_order`, `fld_mrp`, `fld_cost_price`, `fld_selling_price`, `fld_type`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', '1', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:14'),
(2, 1, 'FORTUNE REF SF OIL 4 X 5 LT JAR', '2', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(3, 1, 'FORTUNE KGMO 12 X 1 LT PET C2', '3', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(4, 1, 'FORTUNE REF RICE BRAN OIL 12 X 1 LT PCH', '4', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(5, 1, 'FORTUNE REF SOYA OIL 16 X 1 LT PCH', '5', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(6, 1, 'FORTUNE REF SOYA OIL 4 X 5 LT JAR', '6', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(7, 1, 'RAAG VANASPATI 16X1LTR PCH-N', '7', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(8, 1, 'FORTUNE PURE GN OIL 12 X 1 LT PCH', '8', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(9, 1, 'FORTUNE REGULAR CHAKKI ATTA 6X5KG W2', '9', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(10, 1, 'FORTUNE CHANA BESAN SF 40X500g PCH', '10', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(11, 1, 'FORTUNE CHANA BESAN SUPERFINE 1X10KG BAG', '11', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(12, 1, 'FORTUNE SOYA BARI 320X40GM PCH 10% EX', '12', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(13, 1, 'FORTUNE SOYA BARI MINI 320X40GM P 10% EX', '13', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(14, 1, 'FORTUNE BIRYSPB RICE ST FG 20X1KG PH', '14', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(15, 1, 'FORTUNE EVERYDAYB RICE ST FG 20X1KG PH', '15', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(16, 1, 'KOHINOOR SUPER SILVER ST 20X1KG', '16', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(17, 1, 'ALIFE LIVELY LIME SOAP 48X4X58G BUNDLE', '17', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(18, 1, 'ALIFE LOVELY LILY SOAP 48X4X58G BUNDLE', '18', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(19, 1, 'ALIFE ROMANTIC ROSE SOAP 48X4X58G BND', '19', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(20, 1, 'ALIFE LIME SOAP 30X5X100G BND MRP96', '20', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(21, 1, 'ALIFE LILY SOAP 30X5X100G BND MRP96', '21', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(22, 1, 'ALIFE SANDAL SOAP 30X5X100G BND MRP96', '22', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(23, 1, 'ALIFE ROSE SOAP 30X5X100G BND MRP96', '23', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(24, 1, 'FORTUNE MAIDA 20X500G W1', '24', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(25, 1, 'FORTUNE RAWA 20X500G W1', '25', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(26, 1, 'FORTUNE SUJI 20X500G W1', '26', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(27, 1, 'FORTUNE SUGAR 5 X 5KG BAG', '27', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(28, 1, 'FORTUNE SUGAR 25 X 1KG BAG', '28', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(29, 1, 'FORTUNE POHA 40X500G', '29', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(30, 1, 'FORTUNE INDORI POHA 40X500G', '30', 0, 0.00, 0.00, 0.00, 1, 1, '2024-03-20 02:45:19', '2024-03-20 04:00:25'),
(31, 1, 'FORTUNE REGULAR CHAKKI ATTA 3X10KG W2NP', '31', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:43:58', '2024-03-23 03:55:29'),
(32, 1, 'FORTUNE CHAKKI ATTA 10X1KGW2', '32', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:44:41', '2024-03-23 03:55:32'),
(33, 1, 'FORTUNE SUPER FINE BESAN 20X1 KG PCH', '33', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:45:02', '2024-03-23 03:55:35'),
(34, 1, 'FORTUNE CHANA BESAN SF 60X200GM SCH', '34', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:45:19', '2024-03-23 03:55:39'),
(35, 1, 'FORTUNE PURE GN OIL 4X5LT JAR COU SCH', '35', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:45:40', '2024-03-23 03:55:41'),
(36, 1, 'FORTUNE MAIDA 30X1KG W1', '36', 1, 0.00, 0.00, 0.00, 1, 1, '2024-03-23 03:46:02', '2024-03-23 03:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products_historys`
--

CREATE TABLE `tbl_products_historys` (
  `fld_phid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_remark` varchar(100) DEFAULT NULL COMMENT 'Remark',
  `fld_path` varchar(100) NOT NULL COMMENT 'XLS File Path',
  `fld_file` varchar(100) NOT NULL COMMENT 'File Name',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_products_historys`
--

INSERT INTO `tbl_products_historys` (`fld_phid`, `fld_uid`, `fld_pid`, `fld_remark`, `fld_path`, `fld_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 15, 1, 'NA', 'uploads/products/adani-product-import-final.xlsx', 'adani-product-import-final.xlsx', '2024-03-20 02:45:19', '2024-03-19 21:15:19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_projects`
--

CREATE TABLE `tbl_projects` (
  `fld_pid` int(11) NOT NULL,
  `fld_cid` int(11) DEFAULT NULL,
  `fld_name` varchar(255) DEFAULT NULL,
  `fld_sale_type` tinyint(1) DEFAULT 1 COMMENT '1 = Retail 2=order booking\r\n',
  `fld_consumer_sales` tinyint(1) DEFAULT 1,
  `fld_activity_photos` tinyint(1) DEFAULT 1,
  `fld_start_date` date NOT NULL COMMENT 'Project Start Date',
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_projects`
--

INSERT INTO `tbl_projects` (`fld_pid`, `fld_cid`, `fld_name`, `fld_sale_type`, `fld_consumer_sales`, `fld_activity_photos`, `fld_start_date`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 'Wilmar March 2023', 1, 1, 1, '2024-03-20', 1, '2024-02-25 17:34:33', '2024-04-04 06:29:45');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchases`
--

CREATE TABLE `tbl_purchases` (
  `fld_prid` int(11) NOT NULL,
  `fld_mobile_id` varchar(100) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_project_id` int(11) NOT NULL,
  `fld_sid` int(11) NOT NULL COMMENT 'Stockist ID',
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_bill_photo_path` varchar(255) DEFAULT NULL,
  `fld_bill_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_purchases`
--

INSERT INTO `tbl_purchases` (`fld_prid`, `fld_mobile_id`, `fld_uid`, `fld_project_id`, `fld_sid`, `fld_total`, `fld_date`, `fld_bill_photo_path`, `fld_bill_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_pa6ro1j3', 15, 1, 1, 45.00, '2024-04-01', 'stockiest/15/bill/2024/04', '1711977531.jpg', '2024-04-01 13:18:51', '2024-04-01 13:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchases_items`
--

CREATE TABLE `tbl_purchases_items` (
  `fld_piid` int(11) NOT NULL,
  `fld_mobile_id` varchar(100) NOT NULL,
  `fld_prid` int(11) NOT NULL,
  `fld_project_id` int(11) NOT NULL,
  `fld_product_id` int(11) NOT NULL,
  `fld_product_name` varchar(255) NOT NULL,
  `fld_qty` int(11) NOT NULL,
  `fld_price` decimal(10,2) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_purchases_items`
--

INSERT INTO `tbl_purchases_items` (`fld_piid`, `fld_mobile_id`, `fld_prid`, `fld_project_id`, `fld_product_id`, `fld_product_name`, `fld_qty`, `fld_price`, `fld_total`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_pa6ro1j3', 1, 1, 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 5, 9.00, 45.00, '2024-04-01', '2024-04-01 13:18:51', '2024-04-01 13:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recce`
--

CREATE TABLE `tbl_recce` (
  `fld_raid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_rtype` int(11) NOT NULL COMMENT 'Recce Type',
  `fld_outlet_id` int(11) NOT NULL COMMENT 'Outlet ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_height` double NOT NULL,
  `fld_width` double NOT NULL,
  `fld_area` double NOT NULL COMMENT 'Area',
  `fld_remark` varchar(200) DEFAULT NULL,
  `fld_lat` varchar(20) NOT NULL,
  `fld_long` varchar(20) NOT NULL,
  `fld_installation` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0= No Installation 1=Installation Done',
  `fld_photo_file_recce` varchar(50) DEFAULT NULL,
  `fld_photo_path_recce` varchar(200) DEFAULT NULL,
  `fld_photo_file_install` varchar(50) NOT NULL,
  `fld_photo_path_install` varchar(200) NOT NULL,
  `fld_approved` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_install_date` datetime DEFAULT NULL,
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_recce`
--

INSERT INTO `tbl_recce` (`fld_raid`, `fld_uid`, `fld_rtype`, `fld_outlet_id`, `fld_pid`, `fld_height`, `fld_width`, `fld_area`, `fld_remark`, `fld_lat`, `fld_long`, `fld_installation`, `fld_photo_file_recce`, `fld_photo_path_recce`, `fld_photo_file_install`, `fld_photo_path_install`, `fld_approved`, `fld_install_date`, `fld_created_at`, `fld_updated_at`) VALUES
(2, 18, 1, 4, 1, 30, 45, 456, '444', '12.44454', '34.34433', 1, '1713124407.png', 'branding/recce/182024/04', '1713122556.jpg', 'branding/install//2024/04', 1, NULL, '2024-04-15 00:52:36', '2024-04-15 01:23:27'),
(3, 18, 1, 4, 1, 30, 45, 456, '444', '12.44454', '34.34433', 1, '1713124630.webp', 'branding/recce/182024/04', '1713122564.jpg', 'branding/install//2024/04', 1, NULL, '2024-04-15 00:52:44', '2024-04-15 01:27:10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recce_images`
--

CREATE TABLE `tbl_recce_images` (
  `fld_riid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_outlet_id` int(11) NOT NULL COMMENT 'Outlet ID',
  `fld_raid` int(11) NOT NULL COMMENT 'Recce ID',
  `fld_rtype` int(11) NOT NULL COMMENT 'Recce Photo Type',
  `fld_path` varchar(200) NOT NULL COMMENT 'Image Path',
  `fld_image` varchar(50) NOT NULL COMMENT 'Image Name',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recce_outlets`
--

CREATE TABLE `tbl_recce_outlets` (
  `fld_oid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_uid` int(11) NOT NULL COMMENT 'user ID',
  `fld_state_id` int(11) NOT NULL,
  `fld_district_id` int(11) NOT NULL,
  `fld_town_id` int(11) NOT NULL,
  `fld_outlet` varchar(100) NOT NULL,
  `fld_number` varchar(10) DEFAULT NULL,
  `fld_remark` varchar(100) DEFAULT NULL,
  `fld_direct_install` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_recce_date` datetime DEFAULT NULL COMMENT 'Recce Date',
  `fld_install_date` datetime DEFAULT NULL COMMENT 'Installation Date Date',
  `fld_lat` varchar(20) DEFAULT NULL,
  `fld_long` varchar(20) DEFAULT NULL,
  `fld_approved` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_recce_outlets`
--

INSERT INTO `tbl_recce_outlets` (`fld_oid`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_outlet`, `fld_number`, `fld_remark`, `fld_direct_install`, `fld_recce_date`, `fld_install_date`, `fld_lat`, `fld_long`, `fld_approved`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 18, 14, 1, 1, 'Gupta Stores', '', '', 0, NULL, NULL, NULL, NULL, 1, '2024-04-02 10:06:08', '2024-04-02 10:06:35'),
(2, 1, 18, 14, 1, 1, 'Harish Stores', '', '', 0, NULL, NULL, NULL, NULL, 1, '2024-04-02 10:06:08', '2024-04-02 10:06:35'),
(3, 1, 18, 14, 1, 1, 'Anand Stores', '', '', 0, NULL, NULL, NULL, NULL, 1, '2024-04-02 10:06:08', '2024-04-02 10:06:35'),
(4, 1, 18, 14, 1, 1, 'Test  1', '1236666666', 'test remark', 0, NULL, NULL, '12.2344', '71.2321', 1, '2024-04-14 23:30:12', '2024-04-14 23:38:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recce_routes`
--

CREATE TABLE `tbl_recce_routes` (
  `fld_rpid` int(11) NOT NULL,
  `fld_rphid` int(11) DEFAULT NULL,
  `fld_pid` int(11) DEFAULT NULL COMMENT 'Project ID',
  `fld_uid` int(11) DEFAULT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_town_id` int(11) DEFAULT NULL,
  `fld_user` varchar(100) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_recce_routes`
--

INSERT INTO `tbl_recce_routes` (`fld_rpid`, `fld_rphid`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_user`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 0, 1, 18, 14, 1, 1, 'adanivan1', '2024-03-20 08:33:00', '2024-04-14 15:03:20'),
(2, 0, 1, 18, 14, 1, 1, 'adanivan1', '2024-03-20 08:33:00', '2024-04-14 15:03:27'),
(3, 0, 1, 17, 14, 1, 1, 'adanivan1', '2024-03-20 08:33:00', '2024-03-26 11:32:22'),
(4, 0, 1, 17, 14, 1, 2, 'adanivan1', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(5, 0, 1, 17, 14, 1, 2, 'adanivan1', '2024-03-20 08:33:00', '2024-03-26 11:32:28'),
(6, 0, 1, 18, 14, 2, 3, 'adanivan2', '2024-03-20 08:33:00', '2024-04-14 15:03:32'),
(7, 0, 1, 18, 14, 2, 4, 'adanivan2', '2024-03-20 08:33:00', '2024-04-14 15:03:36'),
(8, 0, 1, 17, 14, 2, 5, 'adanivan2', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(9, 0, 1, 17, 14, 2, 6, 'adanivan2', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(10, 0, 1, 17, 14, 2, 6, 'adanivan2', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(11, 0, 1, 17, 14, 3, 7, 'adanivan3', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(12, 0, 1, 17, 14, 3, 7, 'adanivan3', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(13, 0, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(14, 0, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(15, 0, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(16, 0, 1, 17, 14, 4, 9, 'adanivan4', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(17, 0, 1, 17, 14, 4, 9, 'adanivan4', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(18, 0, 1, 17, 14, 4, 10, 'adanivan4', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(19, 0, 1, 17, 14, 4, 10, 'adanivan4', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(20, 0, 1, 17, 14, 4, 11, 'adanivan4', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(21, 0, 1, 17, 14, 5, 12, 'adanivan5', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(22, 0, 1, 17, 14, 5, 13, 'adanivan5', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(23, 0, 1, 17, 14, 5, 14, 'adanivan5', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(24, 0, 1, 17, 14, 5, 15, 'adanivan5', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(25, 0, 1, 17, 14, 5, 16, 'adanivan5', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(26, 0, 1, 17, 14, 6, 17, 'adanivan6', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(27, 0, 1, 17, 14, 6, 18, 'adanivan6', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(28, 0, 1, 17, 14, 6, 18, 'adanivan6', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(29, 0, 1, 17, 14, 6, 18, 'adanivan6', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(30, 0, 1, 17, 14, 7, 19, 'adanivan7', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(31, 0, 1, 17, 14, 7, 19, 'adanivan7', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(32, 0, 1, 17, 14, 7, 20, 'adanivan7', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(33, 0, 1, 17, 14, 7, 20, 'adanivan7', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(34, 0, 1, 17, 14, 8, 21, 'adanivan8', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(35, 0, 1, 17, 14, 8, 21, 'adanivan8', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(36, 0, 1, 17, 14, 8, 21, 'adanivan8', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(37, 0, 1, 17, 14, 8, 21, 'adanivan8', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(38, 0, 1, 17, 14, 8, 21, 'adanivan8', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(39, 0, 1, 17, 14, 9, 22, 'adanivan9', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(40, 0, 1, 17, 14, 9, 22, 'adanivan9', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(41, 0, 1, 17, 14, 9, 22, 'adanivan9', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(42, 0, 1, 17, 14, 9, 22, 'adanivan9', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(43, 0, 1, 17, 14, 9, 22, 'adanivan9', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(44, 0, 1, 17, 14, 10, 23, 'adanivan10', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(45, 0, 1, 17, 14, 10, 23, 'adanivan10', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(46, 0, 1, 17, 14, 10, 24, 'adanivan10', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(47, 0, 1, 17, 14, 10, 25, 'adanivan10', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(48, 0, 1, 17, 14, 10, 25, 'adanivan10', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(49, 0, 1, 17, 14, 11, 26, 'adanivan11', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(50, 0, 1, 17, 14, 11, 27, 'adanivan11', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(51, 0, 1, 17, 14, 11, 28, 'adanivan11', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(52, 0, 1, 17, 14, 11, 29, 'adanivan11', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(53, 0, 1, 17, 14, 12, 30, 'adanivan12', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(54, 0, 1, 17, 14, 12, 30, 'adanivan12', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(55, 0, 1, 17, 14, 12, 30, 'adanivan12', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(56, 0, 1, 17, 14, 12, 30, 'adanivan12', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(57, 0, 1, 17, 14, 13, 31, 'adanivan12', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(58, 0, 1, 17, 14, 14, 32, 'adanivan13', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(59, 0, 1, 17, 14, 14, 32, 'adanivan13', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(60, 0, 1, 17, 14, 14, 33, 'adanivan13', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(61, 0, 1, 17, 14, 14, 33, 'adanivan13', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(62, 0, 1, 17, 14, 14, 33, 'adanivan13', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(63, 0, 1, 17, 14, 1, 1, 'vandemo', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(64, 0, 1, 17, 14, 1, 1, 'vandemo', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(65, 0, 1, 17, 14, 1, 1, 'vandemo', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(66, 0, 1, 17, 14, 1, 2, 'vandemo', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(67, 0, 1, 17, 14, 1, 2, 'vandemo', '2024-03-20 08:33:00', '2024-03-25 12:14:50'),
(68, NULL, 1, 17, 14, 1, 1, 'adanivan1', '2024-03-20 11:05:00', '2024-03-25 12:14:50'),
(69, NULL, 1, 17, 14, 6, 17, 'adanivan6', '2024-03-20 11:17:01', '2024-03-25 12:14:50'),
(70, NULL, 1, 17, 14, 6, 17, 'adanivan6', '2024-03-21 04:25:07', '2024-03-25 12:14:50'),
(71, NULL, 1, 17, 14, 6, 17, 'adanivan6', '2024-03-21 04:42:01', '2024-03-25 12:14:50'),
(72, NULL, 1, 17, 14, 12, 30, 'adanivan12', '2024-03-21 07:23:44', '2024-03-25 12:14:50'),
(73, NULL, 1, 17, 14, 2, 4, 'adanivan2', '2024-03-21 09:26:51', '2024-03-25 12:14:50'),
(74, NULL, 1, 17, 14, 2, 4, 'adanivan2', '2024-03-21 09:31:58', '2024-03-25 12:14:50'),
(75, NULL, 1, 17, 14, 1, 1, 'adanivan1', '2024-03-21 11:22:17', '2024-03-25 12:14:50'),
(76, NULL, 1, 17, 14, 1, 3, 'adanivan5', '2024-03-21 14:12:10', '2024-03-25 12:14:50'),
(77, NULL, 1, 17, 14, 4, 10, 'adanivan4', '2024-03-22 09:53:50', '2024-03-25 12:14:50'),
(78, NULL, 1, 17, 14, 2, 5, 'adanivan2', '2024-03-22 10:19:28', '2024-03-25 12:14:50'),
(79, NULL, 1, 17, 14, 2, 5, 'adanivan2', '2024-03-22 10:47:29', '2024-03-25 12:14:50'),
(80, NULL, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-22 11:15:47', '2024-03-25 12:14:50'),
(81, NULL, 1, 17, 14, 2, 5, 'adanivan2', '2024-03-22 11:19:25', '2024-03-25 12:14:50'),
(82, NULL, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-22 11:23:14', '2024-03-25 12:14:50'),
(83, NULL, 1, 17, 14, 3, 8, 'adanivan3', '2024-03-22 12:55:20', '2024-03-25 12:14:50'),
(84, NULL, 1, 17, 14, 2, 6, 'adanivan2', '2024-03-23 03:56:00', '2024-03-25 12:14:50'),
(85, NULL, 1, 17, 14, 11, 28, 'adanivan11', '2024-03-23 05:28:42', '2024-03-25 12:14:50'),
(86, NULL, 1, 17, 14, 11, 28, 'adanivan11', '2024-03-23 06:07:24', '2024-03-25 12:14:50'),
(87, NULL, 1, 17, 14, 11, 28, 'adanivan11', '2024-03-23 06:18:18', '2024-03-25 12:14:50'),
(88, NULL, 1, 17, 14, 11, 28, 'adanivan11', '2024-03-23 06:20:56', '2024-03-25 12:14:50'),
(89, NULL, 1, 17, 14, 11, 28, 'vandemo', '2024-03-23 06:31:40', '2024-03-25 12:14:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recce_route_historys`
--

CREATE TABLE `tbl_recce_route_historys` (
  `fld_rhid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL COMMENT 'User ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_direct_installations` tinyint(1) DEFAULT 0 COMMENT 'Direct installation 0=NO 1 = Yes',
  `fld_remark` varchar(100) DEFAULT NULL COMMENT 'Remark',
  `fld_path` varchar(100) NOT NULL COMMENT 'XLS File Path',
  `fld_file` varchar(100) NOT NULL COMMENT 'File Name',
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_retailers`
--

CREATE TABLE `tbl_retailers` (
  `fld_rid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_uid` int(11) NOT NULL,
  `fld_store_name` varchar(255) NOT NULL,
  `fld_owner_name` varchar(255) NOT NULL,
  `fld_number` varchar(255) NOT NULL,
  `fld_type` tinyint(4) NOT NULL COMMENT '(1 = Retailer / 2 = Wholesaler)',
  `fld_comments_1` varchar(255) DEFAULT NULL,
  `fld_comments_2` varchar(255) DEFAULT NULL,
  `fld_comments_3` varchar(255) DEFAULT NULL,
  `fld_village_id` int(11) NOT NULL,
  `fld_tehsil_id` int(11) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_photo_path` varchar(255) DEFAULT NULL,
  `fld_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_retailers`
--

INSERT INTO `tbl_retailers` (`fld_rid`, `fld_mobile_id`, `fld_pid`, `fld_did`, `fld_state_id`, `fld_uid`, `fld_store_name`, `fld_owner_name`, `fld_number`, `fld_type`, `fld_comments_1`, `fld_comments_2`, `fld_comments_3`, `fld_village_id`, `fld_tehsil_id`, `fld_lat`, `fld_long`, `fld_photo_path`, `fld_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_Z9TGMz5X', 1, 1, 14, 15, 'test', 'nit', '9856321478', 1, NULL, NULL, NULL, 1, 1, 22.64497560, 75.83330940, 'retailers/15/store/2024/04', '1711976528.jpg', '2024-04-01 13:02:08', '2024-04-01 13:02:08'),
(2, '17_aRQM2u1H', 1, 1, 14, 17, 'test store', 'nit', '8965231470', 1, NULL, NULL, NULL, 86, 1, 22.64493210, 75.83314070, 'retailers/17/store/2024/04', '1712032667.jpg', '2024-04-02 04:37:47', '2024-04-02 04:37:47'),
(15, 'arty3232', 1, 1, 14, 7, 'Test Store 2', 'Test Owner 2', '2222222288', 2, NULL, NULL, NULL, 69, 3, NULL, NULL, NULL, NULL, '2024-04-07 15:49:50', '2024-04-07 15:49:50'),
(16, '15_j4B7xwKl', 1, 1, 14, 15, 'hi', 'vhi', '5556666666', 1, NULL, NULL, NULL, 1, 1, 22.64489030, 75.83318820, NULL, NULL, '2024-04-08 06:49:41', '2024-04-08 06:49:41'),
(17, '15_fAoQkfJN', 1, 1, 14, 15, 'fh', 'xfy', '2135698740', 1, NULL, NULL, NULL, 1, 1, 22.64491920, 75.83312110, 'retailers/15/store/2024/04', '1712573590.jpg', '2024-04-08 10:53:10', '2024-04-08 10:53:10'),
(18, '15_baA4dpiA', 1, 1, 14, 15, 'gy', 'vvh', '8868888888', 1, NULL, NULL, NULL, 1, 1, 22.64492270, 75.83309150, 'retailers/15/store/2024/04', '1712573935.jpg', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(19, '15_NH9EhYTp', 1, 1, 14, 15, 'test', 'local', '8855555666', 1, NULL, NULL, NULL, 1, 1, 22.64489360, 75.83309210, 'retailers/15/store/2024/04', '1712574672.jpg', '2024-04-08 11:11:12', '2024-04-08 11:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_retailers_fields`
--

CREATE TABLE `tbl_retailers_fields` (
  `fld_rfid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL COMMENT 'Retailer mobile ID',
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_rid` int(11) NOT NULL COMMENT 'Retailer ID',
  `fld_cfid` int(11) NOT NULL COMMENT 'Custom Field ID',
  `fld_choice` text NOT NULL COMMENT 'Field Answer',
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_retailers_fields`
--

INSERT INTO `tbl_retailers_fields` (`fld_rfid`, `fld_mobile_id`, `fld_pid`, `fld_rid`, `fld_cfid`, `fld_choice`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_baA4dpiA', 1, 18, 1, '0', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(2, '15_baA4dpiA', 1, 18, 2, '', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(3, '15_baA4dpiA', 1, 18, 4, '', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(4, '15_baA4dpiA', 1, 18, 3, 'Small', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(5, '15_baA4dpiA', 1, 18, 5, 'chh', '2024-04-08 10:58:55', '2024-04-08 10:58:55'),
(6, '15_NH9EhYTp', 1, 19, 1, '1', '2024-04-08 11:11:12', '2024-04-08 11:11:12'),
(7, '15_NH9EhYTp', 1, 19, 2, '', '2024-04-08 11:11:12', '2024-04-08 11:11:12'),
(8, '15_NH9EhYTp', 1, 19, 4, '85', '2024-04-08 11:11:12', '2024-04-08 11:11:12'),
(9, '15_NH9EhYTp', 1, 19, 3, 'Small', '2024-04-08 11:11:12', '2024-04-08 11:11:12'),
(10, '15_NH9EhYTp', 1, 19, 5, 'cgg', '2024-04-08 11:11:12', '2024-04-08 11:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_retail_sales`
--

CREATE TABLE `tbl_retail_sales` (
  `fld_rsid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) NOT NULL COMMENT 'mobile db order id',
  `fld_rid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_remark` varchar(500) DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_bill_photo_path` varchar(255) DEFAULT NULL,
  `fld_bill_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_retail_sales`
--

INSERT INTO `tbl_retail_sales` (`fld_rsid`, `fld_mobile_id`, `fld_rid`, `fld_uid`, `fld_pid`, `fld_total`, `fld_date`, `fld_remark`, `fld_lat`, `fld_long`, `fld_bill_photo_path`, `fld_bill_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_uRvat91d', 1, 15, 1, 340.00, '2024-04-01', 'test2', 22.64509500, 75.83306500, 'retailers/15/bill/2024/04', '1711976567.jpg', '2024-04-01 13:02:47', '2024-04-11 18:46:02'),
(2, '15_RzpGqZzF', 18, 15, 1, 81.00, '2024-04-10', 'test1', 22.64488470, 75.83305900, 'retailers/15/bill/2024/04', '1712762752.jpg', '2024-04-10 15:25:52', '2024-04-11 18:45:58'),
(3, '15_s2UVSSWe', 1, 15, 1, 8771.00, '2024-04-11', 'test3', 22.64492410, 75.83309860, NULL, NULL, '2024-04-11 05:51:21', '2024-04-11 18:46:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_retail_sales_items`
--

CREATE TABLE `tbl_retail_sales_items` (
  `fld_rsiid` int(11) NOT NULL,
  `fld_rsid` int(11) NOT NULL,
  `fld_mobile_id` varchar(20) DEFAULT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_product` varchar(255) NOT NULL,
  `fld_qty` int(11) NOT NULL,
  `fld_price` decimal(10,2) NOT NULL,
  `fld_total` decimal(10,2) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_retail_sales_items`
--

INSERT INTO `tbl_retail_sales_items` (`fld_rsiid`, `fld_rsid`, `fld_mobile_id`, `fld_pid`, `fld_product`, `fld_qty`, `fld_price`, `fld_total`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, '15_uRvat91d', 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 85, 4.00, 340.00, '2024-04-01', '2024-04-01 13:02:47', '2024-04-01 13:02:47'),
(2, 2, '15_RzpGqZzF', 8, 'FORTUNE PURE GN OIL 12 X 1 LT PCH', 9, 9.00, 81.00, '2024-04-10', '2024-04-10 15:25:52', '2024-04-10 15:25:52'),
(3, 3, '15_s2UVSSWe', 1, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 9, 956.00, 8604.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21'),
(4, 3, '15_s2UVSSWe', 2, 'FORTUNE REF SF OIL 4 X 5 LT JAR', 5, 9.00, 45.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21'),
(5, 3, '15_s2UVSSWe', 3, 'FORTUNE KGMO 12 X 1 LT PET C2', 5, 8.00, 40.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21'),
(6, 3, '15_s2UVSSWe', 4, 'FORTUNE REF RICE BRAN OIL 12 X 1 LT PCH', 2, 6.00, 12.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21'),
(7, 3, '15_s2UVSSWe', 5, 'FORTUNE REF SOYA OIL 16 X 1 LT PCH', 5, 6.00, 30.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21'),
(8, 3, '15_s2UVSSWe', 6, 'FORTUNE REF SOYA OIL 4 X 5 LT JAR', 8, 5.00, 40.00, '2024-04-11', '2024-04-11 05:51:21', '2024-04-11 05:51:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_route_plans`
--

CREATE TABLE `tbl_route_plans` (
  `fld_rpid` int(11) NOT NULL,
  `fld_rphid` int(11) DEFAULT NULL,
  `fld_pid` int(11) DEFAULT NULL,
  `fld_uid` int(11) DEFAULT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_tehsil_id` int(11) DEFAULT NULL,
  `fld_village_id` int(11) DEFAULT NULL,
  `fld_user` varchar(255) DEFAULT NULL,
  `fld_date` date NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_route_plans`
--

INSERT INTO `tbl_route_plans` (`fld_rpid`, `fld_rphid`, `fld_pid`, `fld_uid`, `fld_state_id`, `fld_district_id`, `fld_tehsil_id`, `fld_village_id`, `fld_user`, `fld_date`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 0, 1, 15, 14, 1, 1, 1, 'adanivan1', '2024-04-09', '2024-03-20 08:33:00', '2024-04-09 13:56:39'),
(2, 0, 1, 15, 14, 1, 1, 2, 'adanivan1', '2024-04-10', '2024-03-20 08:33:00', '2024-04-09 13:56:42'),
(3, 0, 1, 15, 14, 1, 1, 3, 'adanivan1', '2024-04-11', '2024-03-20 08:33:00', '2024-04-09 13:56:44'),
(4, 0, 1, 15, 14, 1, 2, 4, 'adanivan1', '2024-04-12', '2024-03-20 08:33:00', '2024-04-09 13:56:46'),
(5, 0, 1, 15, 14, 1, 2, 5, 'adanivan1', '2024-04-13', '2024-03-20 08:33:00', '2024-04-09 13:56:49'),
(6, 0, 1, 15, 14, 2, 3, 6, 'adanivan2', '2024-04-14', '2024-03-20 08:33:00', '2024-04-09 13:57:04'),
(7, 0, 1, 3, 14, 2, 4, 7, 'adanivan2', '2024-03-15', '2024-03-20 08:33:00', '2024-04-09 10:47:23'),
(8, 0, 1, 3, 14, 2, 5, 8, 'adanivan2', '2024-03-16', '2024-03-20 08:33:00', '2024-04-09 10:47:29'),
(9, 0, 1, 3, 14, 2, 6, 9, 'adanivan2', '2024-03-17', '2024-03-20 08:33:00', '2024-04-09 10:47:34'),
(10, 0, 1, 3, 14, 2, 6, 10, 'adanivan2', '2024-03-18', '2024-03-20 08:33:00', '2024-04-09 10:47:39'),
(11, 0, 1, 4, 14, 3, 7, 11, 'adanivan3', '2024-04-19', '2024-03-20 08:33:00', '2024-04-09 10:47:47'),
(12, 0, 1, 4, 14, 3, 7, 12, 'adanivan3', '2024-04-20', '2024-03-20 08:33:00', '2024-04-09 10:47:59'),
(13, 0, 1, 4, 14, 3, 8, 13, 'adanivan3', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(14, 0, 1, 4, 14, 3, 8, 14, 'adanivan3', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(15, 0, 1, 4, 14, 3, 8, 15, 'adanivan3', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(16, 0, 1, 5, 14, 4, 9, 16, 'adanivan4', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(17, 0, 1, 5, 14, 4, 9, 17, 'adanivan4', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(18, 0, 1, 5, 14, 4, 10, 18, 'adanivan4', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(19, 0, 1, 5, 14, 4, 10, 19, 'adanivan4', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(20, 0, 1, 5, 14, 4, 11, 20, 'adanivan4', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(21, 0, 1, 6, 14, 5, 12, 21, 'adanivan5', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(22, 0, 1, 6, 14, 5, 13, 22, 'adanivan5', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(23, 0, 1, 6, 14, 5, 14, 23, 'adanivan5', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(24, 0, 1, 6, 14, 5, 15, 24, 'adanivan5', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(25, 0, 1, 6, 14, 5, 16, 25, 'adanivan5', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(26, 0, 1, 7, 14, 6, 17, 26, 'adanivan6', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(27, 0, 1, 7, 14, 6, 18, 27, 'adanivan6', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(28, 0, 1, 7, 14, 6, 18, 28, 'adanivan6', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(29, 0, 1, 7, 14, 6, 18, 29, 'adanivan6', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(30, 0, 1, 8, 14, 7, 19, 30, 'adanivan7', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(31, 0, 1, 8, 14, 7, 19, 31, 'adanivan7', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(32, 0, 1, 8, 14, 7, 20, 32, 'adanivan7', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(33, 0, 1, 8, 14, 7, 20, 33, 'adanivan7', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(34, 0, 1, 9, 14, 8, 21, 34, 'adanivan8', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(35, 0, 1, 9, 14, 8, 21, 35, 'adanivan8', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(36, 0, 1, 9, 14, 8, 21, 36, 'adanivan8', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(37, 0, 1, 9, 14, 8, 21, 37, 'adanivan8', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(38, 0, 1, 9, 14, 8, 21, 38, 'adanivan8', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(39, 0, 1, 10, 14, 9, 22, 39, 'adanivan9', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(40, 0, 1, 10, 14, 9, 22, 40, 'adanivan9', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(41, 0, 1, 10, 14, 9, 22, 41, 'adanivan9', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(42, 0, 1, 10, 14, 9, 22, 42, 'adanivan9', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(43, 0, 1, 10, 14, 9, 22, 43, 'adanivan9', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(44, 0, 1, 11, 14, 10, 23, 44, 'adanivan10', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(45, 0, 1, 11, 14, 10, 23, 45, 'adanivan10', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(46, 0, 1, 11, 14, 10, 24, 46, 'adanivan10', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(47, 0, 1, 11, 14, 10, 25, 47, 'adanivan10', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(48, 0, 1, 11, 14, 10, 25, 48, 'adanivan10', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(49, 0, 1, 12, 14, 11, 26, 49, 'adanivan11', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(50, 0, 1, 12, 14, 11, 27, 50, 'adanivan11', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(51, 0, 1, 12, 14, 11, 28, 51, 'adanivan11', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(52, 0, 1, 12, 14, 11, 29, 52, 'adanivan11', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(53, 0, 1, 13, 14, 12, 30, 53, 'adanivan12', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(54, 0, 1, 13, 14, 12, 30, 54, 'adanivan12', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(55, 0, 1, 13, 14, 12, 30, 55, 'adanivan12', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(56, 0, 1, 13, 14, 12, 30, 56, 'adanivan12', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(57, 0, 1, 13, 14, 13, 31, 57, 'adanivan12', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(58, 0, 1, 14, 14, 14, 32, 58, 'adanivan13', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(59, 0, 1, 14, 14, 14, 32, 59, 'adanivan13', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(60, 0, 1, 14, 14, 14, 33, 60, 'adanivan13', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(61, 0, 1, 14, 14, 14, 33, 61, 'adanivan13', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(62, 0, 1, 14, 14, 14, 33, 62, 'adanivan13', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(63, 0, 1, 15, 14, 1, 1, 1, 'vandemo', '2024-03-20', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(64, 0, 1, 15, 14, 1, 1, 2, 'vandemo', '2024-03-21', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(65, 0, 1, 15, 14, 1, 1, 3, 'vandemo', '2024-03-22', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(66, 0, 1, 15, 14, 1, 2, 4, 'vandemo', '2024-03-23', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(67, 0, 1, 15, 14, 1, 2, 5, 'vandemo', '2024-03-24', '2024-03-20 08:33:00', '2024-03-20 08:33:00'),
(68, NULL, 1, 2, 14, 1, 1, 63, 'adanivan1', '2024-03-20', '2024-03-20 11:05:00', '2024-03-20 11:05:00'),
(69, NULL, 1, 7, 14, 6, 17, 64, 'adanivan6', '2024-03-21', '2024-03-20 11:17:01', '2024-03-20 11:17:01'),
(70, NULL, 1, 7, 14, 6, 17, 65, 'adanivan6', '2024-03-21', '2024-03-21 04:25:07', '2024-03-21 04:25:07'),
(71, NULL, 1, 7, 14, 6, 17, 65, 'adanivan6', '2024-03-21', '2024-03-21 04:42:01', '2024-03-21 04:42:01'),
(72, NULL, 1, 13, 14, 12, 30, 66, 'adanivan12', '2024-03-20', '2024-03-21 07:23:44', '2024-03-21 07:23:44'),
(73, NULL, 1, 3, 14, 2, 4, 67, 'adanivan2', '2024-03-21', '2024-03-21 09:26:51', '2024-03-21 09:26:51'),
(74, NULL, 1, 3, 14, 2, 4, 67, 'adanivan2', '2024-03-21', '2024-03-21 09:31:58', '2024-03-21 09:31:58'),
(75, NULL, 1, 2, 14, 1, 1, 68, 'adanivan1', '2024-03-21', '2024-03-21 11:22:17', '2024-03-21 11:22:17'),
(76, NULL, 1, 6, 14, 1, 3, 69, 'adanivan5', '2024-03-01', '2024-03-21 14:12:10', '2024-03-21 14:12:10'),
(77, NULL, 1, 5, 14, 4, 10, 70, 'adanivan4', '2024-03-22', '2024-03-22 09:53:50', '2024-03-22 09:53:50'),
(78, NULL, 1, 3, 14, 2, 5, 71, 'adanivan2', '2024-03-22', '2024-03-22 10:19:28', '2024-03-22 10:19:28'),
(79, NULL, 1, 3, 14, 2, 5, 71, 'adanivan2', '2024-03-22', '2024-03-22 10:47:29', '2024-03-22 10:47:29'),
(80, NULL, 1, 4, 14, 3, 8, 72, 'adanivan3', '2024-03-22', '2024-03-22 11:15:47', '2024-03-22 11:15:47'),
(81, NULL, 1, 3, 14, 2, 5, 73, 'adanivan2', '2024-03-22', '2024-03-22 11:19:25', '2024-03-22 11:19:25'),
(82, NULL, 1, 4, 14, 3, 8, 74, 'adanivan3', '2024-03-22', '2024-03-22 11:23:14', '2024-03-22 11:23:14'),
(83, NULL, 1, 4, 14, 3, 8, 75, 'adanivan3', '2024-03-22', '2024-03-22 12:55:20', '2024-03-22 12:55:20'),
(84, NULL, 1, 3, 14, 2, 6, 76, 'adanivan2', '2024-03-23', '2024-03-23 03:56:00', '2024-03-23 03:56:00'),
(85, NULL, 1, 12, 14, 11, 28, 77, 'adanivan11', '2024-03-23', '2024-03-23 05:28:42', '2024-03-23 05:28:42'),
(86, NULL, 1, 12, 14, 11, 28, 78, 'adanivan11', '2024-03-23', '2024-03-23 06:07:24', '2024-03-23 06:07:24'),
(87, NULL, 1, 12, 14, 11, 28, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:18:18', '2024-03-23 06:18:18'),
(88, NULL, 1, 12, 14, 11, 28, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:20:56', '2024-03-23 06:20:56'),
(89, NULL, 1, 12, 14, 11, 28, 79, 'adanivan11', '2024-03-23', '2024-03-23 06:31:40', '2024-03-23 06:31:40'),
(90, NULL, 1, 15, 14, 1, 2, 80, 'vandemo', '2024-03-24', '2024-03-28 05:30:57', '2024-03-28 05:30:57'),
(91, NULL, 1, 15, 14, 1, 1, 81, 'vandemo', '2024-03-21', '2024-03-28 05:34:31', '2024-03-28 05:34:31'),
(92, NULL, 1, 15, 14, 1, 1, 82, 'vandemo', '2024-03-22', '2024-03-28 05:45:22', '2024-03-28 05:45:22'),
(93, NULL, 1, 15, 14, 1, 1, 83, 'vandemo', '2024-03-22', '2024-03-28 05:52:30', '2024-03-28 05:52:30'),
(94, NULL, 1, 15, 14, 1, 1, 84, 'vandemo', '2024-03-20', '2024-03-28 06:23:06', '2024-03-28 06:23:06'),
(95, NULL, 1, 15, 14, 1, 1, 85, 'vandemo', '2024-03-20', '2024-03-28 06:29:30', '2024-03-28 06:29:30'),
(96, NULL, 1, 17, 14, 1, 1, 86, 'mandidemo', '2024-03-20', '2024-04-02 04:37:47', '2024-04-02 04:37:47'),
(97, NULL, 1, 7, 14, 1, 3, 69, 'adanivan6', '2024-03-01', '2024-04-07 15:25:51', '2024-04-07 15:25:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_route_plans_historys`
--

CREATE TABLE `tbl_route_plans_historys` (
  `fld_rphid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL COMMENT 'Project ID',
  `fld_remark` varchar(100) NOT NULL COMMENT 'Remark',
  `fld_file_path` varchar(200) NOT NULL COMMENT 'File Path',
  `fld_file_name` varchar(100) NOT NULL COMMENT 'File Name',
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_route_plans_historys`
--

INSERT INTO `tbl_route_plans_historys` (`fld_rphid`, `fld_uid`, `fld_pid`, `fld_remark`, `fld_file_path`, `fld_file_name`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 1, 'NA', 'uploads/routeplans/route - plan - adani - updated.xlsx', 'route - plan - adani - updated.xlsx', '2024-03-20 03:02:59', '2024-03-20 08:32:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_stockists`
--

CREATE TABLE `tbl_stockists` (
  `fld_sid` int(11) NOT NULL,
  `fld_mobile_id` varchar(100) NOT NULL,
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) NOT NULL COMMENT 'State ID',
  `fld_pid` int(11) NOT NULL,
  `fld_uid` int(11) NOT NULL,
  `fld_stockist_name` varchar(255) NOT NULL,
  `fld_firm_name` varchar(255) NOT NULL,
  `fld_number` varchar(255) NOT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_photo_path` varchar(255) DEFAULT NULL,
  `fld_photo_file` varchar(255) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_stockists`
--

INSERT INTO `tbl_stockists` (`fld_sid`, `fld_mobile_id`, `fld_did`, `fld_state_id`, `fld_pid`, `fld_uid`, `fld_stockist_name`, `fld_firm_name`, `fld_number`, `fld_lat`, `fld_long`, `fld_photo_path`, `fld_photo_file`, `fld_created_at`, `fld_updated_at`) VALUES
(1, '15_pa6ro1j3', 1, 14, 1, 15, 'nitesh test', 'test', '9998855555', 22.64487990, 75.83308350, 'stockiest/15/store/2024/04', '1711977531.jpg', '2024-04-01 13:18:51', '2024-04-01 13:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_summaries`
--

CREATE TABLE `tbl_summaries` (
  `fld_sid` int(11) NOT NULL,
  `fld_uid` int(11) DEFAULT NULL,
  `fld_pid` int(11) DEFAULT NULL,
  `fld_scfid` int(11) NOT NULL COMMENT 'Summary Question ID',
  `fld_comment` text NOT NULL COMMENT 'Question Response',
  `fld_date` date DEFAULT NULL,
  `fld_lat` decimal(10,8) DEFAULT NULL,
  `fld_long` decimal(11,8) DEFAULT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_summaries`
--

INSERT INTO `tbl_summaries` (`fld_sid`, `fld_uid`, `fld_pid`, `fld_scfid`, `fld_comment`, `fld_date`, `fld_lat`, `fld_long`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 7, 1, 1, 'test', '2024-04-09', 21.65740000, 18.34260000, '2024-04-09 13:38:41', '2024-04-09 13:38:41'),
(2, 7, 1, 2, 'test1', '2024-04-09', 21.65740000, 18.34260000, '2024-04-09 13:38:41', '2024-04-09 13:38:41'),
(3, 7, 1, 3, 'test2', '2024-04-09', 21.65740000, 18.34260000, '2024-04-09 13:38:41', '2024-04-09 13:38:41'),
(4, 7, 1, 4, 'test3', '2024-04-09', 21.65740000, 18.34260000, '2024-04-09 13:38:41', '2024-04-09 13:38:41'),
(5, 15, 1, 1, '0', '2024-04-09', 22.64491150, 75.83306870, '2024-04-09 14:07:30', '2024-04-09 14:07:30'),
(6, 15, 1, 2, '', '2024-04-09', 22.64491150, 75.83306870, '2024-04-09 14:07:30', '2024-04-09 14:07:30'),
(7, 15, 1, 3, 'Small', '2024-04-09', 22.64491150, 75.83306870, '2024-04-09 14:07:30', '2024-04-09 14:07:30'),
(8, 15, 1, 4, 'vh', '2024-04-09', 22.64491150, 75.83306870, '2024-04-09 14:07:30', '2024-04-09 14:07:30'),
(9, 15, 1, 5, '', '2024-04-09', 22.64491150, 75.83306870, '2024-04-09 14:07:30', '2024-04-09 14:07:30'),
(10, 17, 1, 1, '1', '2024-03-20', 22.64488950, 75.83306280, '2024-04-10 12:30:22', '2024-04-10 12:30:22'),
(11, 17, 1, 2, '', '2024-03-20', 22.64488950, 75.83306280, '2024-04-10 12:30:22', '2024-04-10 12:30:22'),
(12, 17, 1, 3, 'Small', '2024-03-20', 22.64488950, 75.83306280, '2024-04-10 12:30:22', '2024-04-10 12:30:22'),
(13, 17, 1, 4, 'rg', '2024-03-20', 22.64488950, 75.83306280, '2024-04-10 12:30:22', '2024-04-10 12:30:22'),
(14, 17, 1, 5, '', '2024-03-20', 22.64488950, 75.83306280, '2024-04-10 12:30:22', '2024-04-10 12:30:22'),
(15, 17, 1, 1, '0', '2024-03-20', 22.64490220, 75.83307200, '2024-04-10 12:32:00', '2024-04-10 12:32:00'),
(16, 17, 1, 2, '', '2024-03-20', 22.64490220, 75.83307200, '2024-04-10 12:32:00', '2024-04-10 12:32:00'),
(17, 17, 1, 3, 'Small', '2024-03-20', 22.64490220, 75.83307200, '2024-04-10 12:32:00', '2024-04-10 12:32:00'),
(18, 17, 1, 4, 'xf', '2024-03-20', 22.64490220, 75.83307200, '2024-04-10 12:32:00', '2024-04-10 12:32:00'),
(19, 17, 1, 5, 'xd', '2024-03-20', 22.64490220, 75.83307200, '2024-04-10 12:32:00', '2024-04-10 12:32:00'),
(20, 17, 1, 1, '0', '2024-03-20', 22.64490900, 75.83306790, '2024-04-10 12:33:26', '2024-04-10 12:33:26'),
(21, 17, 1, 2, '', '2024-03-20', 22.64490900, 75.83306790, '2024-04-10 12:33:26', '2024-04-10 12:33:26'),
(22, 17, 1, 3, 'Small', '2024-03-20', 22.64490900, 75.83306790, '2024-04-10 12:33:26', '2024-04-10 12:33:26'),
(23, 17, 1, 4, '3', '2024-03-20', 22.64490900, 75.83306790, '2024-04-10 12:33:26', '2024-04-10 12:33:26'),
(24, 17, 1, 5, '', '2024-03-20', 22.64490900, 75.83306790, '2024-04-10 12:33:26', '2024-04-10 12:33:26'),
(25, 15, 1, 1, '0', '2024-04-10', 22.64489800, 75.83305100, '2024-04-10 13:40:08', '2024-04-10 13:40:08'),
(26, 15, 1, 2, '', '2024-04-10', 22.64489800, 75.83305100, '2024-04-10 13:40:08', '2024-04-10 13:40:08'),
(27, 15, 1, 3, 'Small', '2024-04-10', 22.64489800, 75.83305100, '2024-04-10 13:40:08', '2024-04-10 13:40:08'),
(28, 15, 1, 4, 'h', '2024-04-10', 22.64489800, 75.83305100, '2024-04-10 13:40:08', '2024-04-10 13:40:08'),
(29, 15, 1, 5, '', '2024-04-10', 22.64489800, 75.83305100, '2024-04-10 13:40:08', '2024-04-10 13:40:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tokens`
--

CREATE TABLE `tbl_tokens` (
  `fld_tid` int(11) NOT NULL,
  `fld_user_id` int(11) NOT NULL,
  `fld_token` varchar(100) NOT NULL,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_tokens`
--

INSERT INTO `tbl_tokens` (`fld_tid`, `fld_user_id`, `fld_token`, `fld_created_at`, `fld_updated_at`) VALUES
(14, 7, 'QNqs53BBfEZPbnJzFAq7PSKhJoEi6AOINvuh2LvpKKtX8iAMNvSEqhxj38bxr1yM', '2024-03-21 08:30:05', '2024-03-21 08:30:05'),
(26, 14, 'JPRfmqt4tnNlKlTZImUS6cXHPdTajPlTS0zCplGO6Kkat16revH58AE7T7Ty0AwJ', '2024-03-21 11:25:32', '2024-03-21 11:25:32'),
(33, 3, '5HuuGAZNfpPC2pAx49RKUFPpL7GEhR9rixEI7sttE6TTKFeJEZ5CfASBLe5DW9PQ', '2024-03-22 03:33:14', '2024-03-22 03:33:14'),
(35, 3, 'uUTfLTZCUbZj4eRTnHqPDBRnhjtDkhHF7w1FlXWkmLiZJIjzMWbzEBmpZ9b0ZYXZ', '2024-03-22 04:46:56', '2024-03-22 04:46:56'),
(40, 5, 'uuTGQ1JSlFwG3fGGu9UTdoY1uA1UXC6AhigN2KsJXssSPgREkRakKyDdDB1zBmHV', '2024-03-22 09:16:45', '2024-03-22 09:16:45'),
(43, 6, '53q1afZdsHX1v1Fz36ETKDPiNegizuPy1m0paY01UKrJc2OCsTtfgkai1hyyepOW', '2024-03-22 11:01:48', '2024-03-22 11:01:48'),
(46, 4, 'eKM51HiN5Fok9e21l35eyaJWWoAvopzZ9QlC796Hm9JjxJI6pPwAyd6Ve9LQ8XOK', '2024-03-22 11:23:59', '2024-03-22 11:23:59'),
(48, 3, '0Sd2H6V4B2k7qP2T40TuBMi3RenUjF1NH8vcKz4oollRDWLMGU5fgHzRmRWWp8qV', '2024-03-22 14:51:01', '2024-03-22 14:51:01'),
(50, 10, '27ax03B2RymhCptiTcTYHM0HaDxmb6DXShIULJ6f5eJS995VrdvXMwg0yK7WdNEJ', '2024-03-23 03:43:35', '2024-03-23 03:43:35'),
(54, 13, 'N68sPYlKK7p3Rvw1d523cY2SDlMqsBVTzC6EA2ijXl8sfpDm8tWMGzzmaGNcGBL6', '2024-03-23 06:24:37', '2024-03-23 06:24:37'),
(67, 9, '4QRhpEdzZqZDpk697rCgn6ts4Hgi8U27ukdwIBy8K0dTUqY6pNRBf4qOkaDwLtIz', '2024-03-23 08:16:12', '2024-03-23 08:16:12'),
(68, 12, 'xnErua05wb2U0UiyKl2hZ8EuVI7vhr64EPP1TSkmHXJivZVZMRNnyEp7bZApM2Rs', '2024-03-23 08:40:47', '2024-03-23 08:40:47'),
(71, 6, '9nHYTq78eoo8Jeza0dLLVsXJZdHHjmXf9CbskOdz6OZj96mxNe7XxdTgJ2ZaG19l', '2024-03-26 10:02:32', '2024-03-26 10:02:32'),
(74, 2, 'hlq7Z4u8vMm6SbZX6IskuxYUcVgrYW7FXozd6hSINBA9sLhbetQAtf1zreKwb2CZ', '2024-03-26 11:26:57', '2024-03-26 11:26:57'),
(102, 15, 'BT0GbyQubQLFzT5GwLY4tzAYSSgcNpq28lTeKnPGY8FdTs18xQmgeiZTrAuWpdbH', '2024-04-12 08:58:46', '2024-04-12 08:58:46'),
(103, 15, 'rwgZYa5cliasEIvoDT1kPJKgKbFmlvO4j4Ozb0I4puB3cmYp0TYIBlDHwllrBzyO', '2024-04-12 15:44:17', '2024-04-12 15:44:17'),
(104, 18, 'cyc641eutAxlxqlGpEmoIt7p3cyfiOuHKs5JJ3sTV3XoIMa3CqPj5Hq1KWG8su3T', '2024-04-14 15:00:36', '2024-04-14 15:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `fld_uid` int(11) NOT NULL,
  `fld_name` varchar(50) NOT NULL,
  `fld_username` varchar(50) NOT NULL,
  `fld_password` varchar(255) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_project_id` int(11) DEFAULT NULL,
  `fld_role` int(11) NOT NULL DEFAULT 2 COMMENT '1=Admin|2=Field User|3=Mandi|4=Mela | 5= Recce | 6=nebula | 7= Client',
  `fld_fcm_token` varchar(255) DEFAULT NULL,
  `fld_device_manufacture` varchar(100) DEFAULT NULL,
  `fld_device_model` int(11) DEFAULT NULL,
  `fld_os_ver` int(11) DEFAULT NULL,
  `fld_status` tinyint(4) NOT NULL DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`fld_uid`, `fld_name`, `fld_username`, `fld_password`, `fld_state_id`, `fld_project_id`, `fld_role`, `fld_fcm_token`, `fld_device_manufacture`, `fld_device_model`, `fld_os_ver`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 'Admin', 'admin', '$2y$10$RVrevoazMm.V3kg.W4HANerQKMAXqtBQNagdFlLpqXjz/hWXK7iCa', NULL, NULL, 1, NULL, NULL, NULL, NULL, 1, '2024-02-25 14:18:20', '2024-03-18 04:19:06'),
(2, 'adanivan1', 'adanivan1', '$2y$10$ZYYRnpaPj8NjSpi6a/h6xum/acncpIS9fPV7o8GNTD/1hfi2PdtRO', 14, 1, 3, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-26 11:26:57'),
(3, 'adanivan2', 'adanivan2', '$2y$10$o1MsUNiKj7CiqX4sWPNed.d9Jt7OF8XEnQXgYh4ksR9SgLTNP8LZu', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-22 14:51:01'),
(4, 'adanivan3', 'adanivan3', '$2y$10$3tqoh69u8q.CrcDmwxxQ6u5myt5t.iYgg0pH789d35UcOoRGcFyPG', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-22 11:23:59'),
(5, 'adanivan4', 'adanivan4', '$2y$10$1HR1DrzQ/PumnLhRInyVeujfGA.sqnRjJ04tjuSpFiQu0dIMZ.QVy', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-22 09:16:45'),
(6, 'adanivan5', 'adanivan5', '$2y$10$cQ84FD8SUPjaGRC52qYaQ.KgaeDMu38h9nPWDmKW3p5cVg0gukcfy', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-26 10:02:32'),
(7, 'adanivan6', 'adanivan6', '$2y$10$rlnbkjM4VPhFzpQaLjGu.uMvAxPUL0.LAkCjTDeFMN5dRr5iI36/O', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-03-21 08:30:05'),
(8, 'adanivan7', 'adanivan7', '$2y$10$7tN3bfzLbTDkrh8JX/BGYuB7KElVtOme6spLHBV2SQhVkhtVYWPca', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 04:33:57'),
(9, 'adanivan8', 'adanivan8', '$2y$10$aXjO7Myrrgrugtl0PNqMH.qHDFQtQLbMavDnR1SHoHESWUzbkWZDi', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 08:16:12'),
(10, 'adanivan9', 'adanivan9', '$2y$10$KAkk3VhMdnx9w3KP6WKvVuHsq2q60F4wKHtTOYC6ViFURbd0zdf2K', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 03:43:35'),
(11, 'adanivan10', 'adanivan10', '$2y$10$cgZ0JLqNTjnr9y9.VSt4Gua5O3uTJL.aXtmjNbcUnbaAw4XVgQDmq', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 07:57:00'),
(12, 'adanivan11', 'adanivan11', '$2y$10$o039AgzlMINFM69OadrcIOpGzq3EF3LS5ViMtHpPDC4r9JJb/HqiO', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 08:40:47'),
(13, 'adanivan12', 'adanivan12', '$2y$10$gG0/NvGcbpQpQ8FMLhEjaOoCvm7lquZQrFbtHfk8Z37KRHqnpYh2m', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-23 06:24:37'),
(14, 'adanivan13', 'adanivan13', '$2y$10$XZSP1FqKGo2kuWyAqaJaHeRaNGNsNojyW3MJIdX6roPwK8LusPwVm', 14, 1, 2, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:33:00', '2024-03-21 11:25:32'),
(15, 'vandemo', 'vandemo', '$2y$10$FbzGGR8NH.tkiATvt.IeRO7c8OK8XeNsw8S.BsH4/sYGVtCrUTLIW', 14, 1, 2, NULL, 'motorola', NULL, NULL, 1, '2024-03-20 08:33:00', '2024-04-12 15:44:17'),
(16, 'melademo', 'melademo', '$2y$10$FbzGGR8NH.tkiATvt.IeRO7c8OK8XeNsw8S.BsH4/sYGVtCrUTLIW', 14, 1, 4, NULL, 'motorola', NULL, NULL, 1, '2024-03-20 08:33:00', '2024-04-02 04:33:36'),
(17, 'mandidemo', 'mandidemo', '$2y$10$FbzGGR8NH.tkiATvt.IeRO7c8OK8XeNsw8S.BsH4/sYGVtCrUTLIW', 14, 1, 3, NULL, 'motorola', NULL, NULL, 1, '2024-03-20 08:33:00', '2024-04-12 07:30:32'),
(18, 'recceuser1', 'recceuser1', '$2y$10$ZYYRnpaPj8NjSpi6a/h6xum/acncpIS9fPV7o8GNTD/1hfi2PdtRO', 14, 1, 5, NULL, NULL, NULL, NULL, 1, '2024-03-20 08:32:59', '2024-04-14 15:00:36');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_voice_messages`
--

CREATE TABLE `tbl_voice_messages` (
  `fld_vid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `fld_message` varchar(255) NOT NULL,
  `fld_audio_path` varchar(255) NOT NULL,
  `fld_audio_file` varchar(255) NOT NULL,
  `fld_type` varchar(255) NOT NULL COMMENT 'whatever text comes, save that in field',
  `fld_attachment_path` varchar(255) DEFAULT NULL,
  `fld_attachment_file` varchar(255) DEFAULT NULL,
  `fld_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fld_updated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_districts`
--

CREATE TABLE `tbl_x_districts` (
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_districts`
--

INSERT INTO `tbl_x_districts` (`fld_did`, `fld_state_id`, `fld_district`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 'Jalgaon', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 'Buldana', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(3, 14, 'Amravati', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 'Solapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 'Nashik', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 'Ahmadnagar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 'Pune', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 'Aurangabad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(14, 14, 'Sangli', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_districts_mandi`
--

CREATE TABLE `tbl_x_districts_mandi` (
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_districts_mandi`
--

INSERT INTO `tbl_x_districts_mandi` (`fld_did`, `fld_state_id`, `fld_district`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 'Jalgaon', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 'Buldana', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(3, 14, 'Amravati', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 'Solapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 'Nashik', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 'Ahmadnagar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 'Pune', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 'Aurangabad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(14, 14, 'Sangli', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_districts_mela`
--

CREATE TABLE `tbl_x_districts_mela` (
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_districts_mela`
--

INSERT INTO `tbl_x_districts_mela` (`fld_did`, `fld_state_id`, `fld_district`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 'Jalgaon', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 'Buldana', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(3, 14, 'Amravati', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 'Solapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 'Nashik', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 'Ahmadnagar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 'Pune', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 'Aurangabad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(14, 14, 'Sangli', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_districts_recce`
--

CREATE TABLE `tbl_x_districts_recce` (
  `fld_did` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_districts_recce`
--

INSERT INTO `tbl_x_districts_recce` (`fld_did`, `fld_state_id`, `fld_district`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 'Jalgaon', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 'Buldana', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(3, 14, 'Amravati', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 'Solapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 'Nashik', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 'Ahmadnagar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 'Pune', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 'Aurangabad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(14, 14, 'Sangli', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_fields`
--

CREATE TABLE `tbl_x_fields` (
  `fld_cfid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_question` varchar(200) NOT NULL,
  `fld_placeholder` varchar(200) DEFAULT NULL,
  `fld_ans` text DEFAULT NULL,
  `fld_isnumeric` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_display_order` int(11) NOT NULL,
  `fld_type` enum('T','R','S','TA','N') NOT NULL DEFAULT 'T' COMMENT '''T''= Text\r\n''R''= Radio\r\n''S''= Select\r\n''TA''= Text Area\r\n''N''= Number',
  `fld_required` tinyint(1) DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_status` tinyint(4) NOT NULL,
  `fld_created_at` timestamp NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_x_fields`
--

INSERT INTO `tbl_x_fields` (`fld_cfid`, `fld_pid`, `fld_question`, `fld_placeholder`, `fld_ans`, `fld_isnumeric`, `fld_display_order`, `fld_type`, `fld_required`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 'Brand Present?', 'Enter brand name like tata', 'Yes<>No', 0, 1, 'R', 1, 0, '2024-04-03 17:54:52', '2024-04-03 17:54:52'),
(2, 1, 'Enter the competitor distributor name', 'Enter distributor name and address', '', 0, 2, 'TA', 0, 0, '2024-04-05 15:55:10', '2024-04-03 17:54:52'),
(3, 1, 'Select the shop size', NULL, 'Small<>Medium<>Big', 0, 4, 'S', 1, 0, '2024-04-05 15:56:10', '2024-04-03 17:54:52'),
(4, 1, 'How Many Employed in Shop?', 'Number of Employees', '', 1, 3, 'N', 0, 0, '2024-04-05 15:56:51', '2024-04-03 17:54:52'),
(5, 1, 'Shop landmark?', 'Enter the landmark area near the shop', '', 0, 5, 'T', 1, 0, '2024-04-05 15:57:35', '2024-04-03 17:54:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_mandis`
--

CREATE TABLE `tbl_x_mandis` (
  `fld_mid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_town_id` int(11) DEFAULT NULL,
  `fld_mandi` varchar(100) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_mandis`
--

INSERT INTO `tbl_x_mandis` (`fld_mid`, `fld_state_id`, `fld_district_id`, `fld_town_id`, `fld_mandi`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 1, 'Lasur', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 1, 'Chahardi', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 1, 1, 'Adwad', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(4, 14, 1, 2, 'Sakali', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(5, 14, 1, 2, 'Marul', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 3, 'Pimpalgaon Kale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 2, 4, 'Sonala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 2, 5, 'Shegaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 2, 6, 'Nimgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 2, 6, 'Wadner', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 3, 7, 'Kandali', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 3, 7, 'Pathrot', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 3, 8, 'Shirajgaon  Kasba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 3, 8, 'Khel Mahal (Karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 3, 8, 'Khel Chaudhar (karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 4, 9, 'Hiwarkhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 4, 9, 'Adgaon Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 4, 10, 'Paras', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 4, 10, 'Wadegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 4, 11, 'Borgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 5, 12, 'Walour', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 5, 13, 'Bori', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 5, 14, 'Zari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 5, 15, 'Ranisawargaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 5, 16, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 6, 17, 'Kem', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 6, 18, 'Kurdu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 6, 18, 'Bhosare', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 6, 18, 'Tembhurni', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 7, 19, 'Ravalgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 7, 19, 'Dabhadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(32, 14, 7, 20, 'Naydongari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(33, 14, 7, 20, 'Sakore', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(34, 14, 8, 21, 'Sakuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(35, 14, 8, 21, 'Puntamba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(36, 14, 8, 21, 'Wakadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(37, 14, 8, 21, 'Kolhar Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(38, 14, 8, 21, 'Loni Kh.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(39, 14, 9, 22, 'Otur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(40, 14, 9, 22, 'Ale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(41, 14, 9, 22, 'Narayangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(42, 14, 9, 22, 'Warulwadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(43, 14, 9, 22, 'Rajuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(44, 14, 10, 23, 'Shafepur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(45, 14, 10, 23, 'Deogaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(46, 14, 10, 24, 'Fardapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(47, 14, 10, 25, 'Ghatnandra', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(48, 14, 10, 25, 'Undangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(49, 14, 11, 26, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(50, 14, 11, 27, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(51, 14, 11, 28, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(52, 14, 11, 29, 'Salod (Hirapur)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(53, 14, 12, 30, 'Masur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(54, 14, 12, 30, 'Umbraj', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(55, 14, 12, 30, 'Kale', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(56, 14, 12, 30, 'Rethare bk.', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(57, 14, 13, 31, 'Pargaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(58, 14, 14, 32, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(59, 14, 14, 32, 'Mangle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(60, 14, 14, 33, 'Kasegaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(61, 14, 14, 33, 'Wategaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(62, 14, 14, 33, 'Nerle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(63, 14, 1, 1, 'hivrkhed', 1, '2024-03-20 11:05:00', '2024-03-20 11:05:00'),
(64, 14, 6, 17, 'sagrampur', 1, '2024-03-20 11:17:01', '2024-03-20 11:17:01'),
(65, 14, 6, 17, 'sonala', 1, '2024-03-21 04:25:07', '2024-03-21 04:25:07'),
(66, 14, 12, 30, 'pargaon', 1, '2024-03-21 07:23:44', '2024-03-21 07:23:44'),
(67, 14, 2, 4, 'Sangrampur', 1, '2024-03-21 09:26:51', '2024-03-21 09:26:51'),
(68, 14, 1, 1, 'adgaon bk.', 1, '2024-03-21 11:22:17', '2024-03-21 11:22:17'),
(69, 14, 1, 3, 'Dedla', 1, '2024-03-21 14:12:10', '2024-03-21 14:12:10'),
(70, 14, 4, 10, 'balapur', 1, '2024-03-22 09:53:50', '2024-03-22 09:53:50'),
(71, 14, 2, 5, 'manasgaon', 1, '2024-03-22 10:19:28', '2024-03-22 10:19:28'),
(72, 14, 3, 8, 'kharpi', 1, '2024-03-22 11:15:47', '2024-03-22 11:15:47'),
(73, 14, 2, 5, 'khandavi', 1, '2024-03-22 11:19:25', '2024-03-22 11:19:25'),
(74, 14, 3, 8, 'khapri', 1, '2024-03-22 11:23:14', '2024-03-22 11:23:14'),
(75, 14, 3, 8, 'salepur pandhri', 1, '2024-03-22 12:55:20', '2024-03-22 12:55:20'),
(76, 14, 2, 6, 'manegaon', 1, '2024-03-23 03:56:00', '2024-03-23 03:56:00'),
(77, 14, 11, 28, 'alipur', 1, '2024-03-23 05:28:42', '2024-03-23 05:28:42'),
(78, 14, 11, 28, 'alipur  hinganghat', 1, '2024-03-23 06:07:24', '2024-03-23 06:07:24'),
(79, 14, 11, 28, 'hinganghat alipur', 1, '2024-03-23 06:18:18', '2024-03-23 06:18:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_ptypes`
--

CREATE TABLE `tbl_x_ptypes` (
  `fld_ptid` int(11) NOT NULL,
  `fld_purpose` varchar(255) NOT NULL,
  `fld_type` varchar(255) NOT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_ptypes`
--

INSERT INTO `tbl_x_ptypes` (`fld_ptid`, `fld_purpose`, `fld_type`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 'Activity', 'Activity', 1, '2024-02-25 17:18:37', '2024-03-12 08:35:51'),
(2, 'Activity', 'Branding', 1, '2024-02-25 17:18:37', '2024-03-12 08:35:56'),
(3, 'Activity', 'Competitor ', 1, '2024-02-25 17:18:37', '2024-03-12 08:36:00'),
(4, 'Activity', 'Product Display', 1, '2024-02-25 17:18:37', '2024-03-12 08:36:03'),
(5, 'Recce', 'Dealer Board', 1, '2024-03-12 08:34:40', '2024-03-12 08:34:40'),
(6, 'Recce', 'Wall Painting', 1, '2024-03-12 08:34:57', '2024-03-12 08:34:57'),
(7, 'Recce', 'Shop Branding', 1, '2024-03-12 08:35:13', '2024-03-12 08:35:13'),
(8, 'Mela', 'Branding', 1, '2024-03-12 08:35:35', '2024-03-12 08:35:35'),
(9, 'Mela', 'Activity', 1, '2024-03-12 08:35:35', '2024-03-12 08:35:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_recce_types`
--

CREATE TABLE `tbl_x_recce_types` (
  `fld_rtid` int(11) NOT NULL,
  `fld_type` varchar(50) NOT NULL,
  `fld_status` tinyint(4) NOT NULL,
  `fld_created_at` datetime NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_recce_types`
--

INSERT INTO `tbl_x_recce_types` (`fld_rtid`, `fld_type`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 'Dealer Board', 1, '2024-03-12 12:06:18', '2024-03-12 06:36:44'),
(2, 'Wall Painting', 1, '2024-03-12 12:06:18', '2024-03-12 06:36:44'),
(3, 'Shop Branding', 1, '2024-03-12 12:06:47', '2024-03-12 06:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_states`
--

CREATE TABLE `tbl_x_states` (
  `fld_sid` int(11) NOT NULL,
  `fld_state` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_states`
--

INSERT INTO `tbl_x_states` (`fld_sid`, `fld_state`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 'Andhra Pradesh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(2, 'Arunachal Pradesh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(3, 'Assam', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(4, 'Bihar', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(5, 'Chhattisgarh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(6, 'Goa', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(7, 'Gujarat', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(8, 'Haryana', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(9, 'Himachal Pradesh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(10, 'Jharkhand', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(11, 'Karnataka', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(12, 'Kerala', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(13, 'Madhya Pradesh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(14, 'Maharashtra', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(15, 'Manipur', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(16, 'Meghalaya', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(17, 'Mizoram', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(18, 'Nagaland', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(19, 'Odisha', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(20, 'Punjab', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(21, 'Rajasthan', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(22, 'Sikkim', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(23, 'Tamil Nadu', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(24, 'Telangana', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(25, 'Tripura', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(26, 'Uttar Pradesh', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(27, 'Uttarakhand', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(28, 'West Bengal', 1, '2024-02-25 15:07:59', '2024-02-25 15:07:59'),
(29, 'FORTUNE REF SF OIL 16 X 1 LT PCH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(30, 'FORTUNE REF SF OIL 4 X 5 LT JAR', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(31, 'FORTUNE KGMO 12 X 1 LT PET C2', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(32, 'FORTUNE REF RICE BRAN OIL 12 X 1 LT PCH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(33, 'FORTUNE REF SOYA OIL 16 X 1 LT PCH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(34, 'FORTUNE REF SOYA OIL 4 X 5 LT JAR', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(35, 'RAAG VANASPATI 16X1LTR PCH-N', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(36, 'FORTUNE PURE GN OIL 12 X 1 LT PCH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(37, 'FORTUNE REGULAR CHAKKI ATTA 6X5KG W2', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(38, 'FORTUNE CHANA BESAN SF 40X500g PCH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(39, 'FORTUNE CHANA BESAN SUPERFINE 1X10KG BAG', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(40, 'FORTUNE SOYA BARI 320X40GM PCH 10% EX', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(41, 'FORTUNE SOYA BARI MINI 320X40GM P 10% EX', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(42, 'FORTUNE BIRYSPB RICE ST FG 20X1KG PH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(43, 'FORTUNE EVERYDAYB RICE ST FG 20X1KG PH', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(44, 'KOHINOOR SUPER SILVER ST 20X1KG', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(45, 'ALIFE LIVELY LIME SOAP 48X4X58G BUNDLE', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(46, 'ALIFE LOVELY LILY SOAP 48X4X58G BUNDLE', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(47, 'ALIFE ROMANTIC ROSE SOAP 48X4X58G BND', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(48, 'ALIFE LIME SOAP 30X5X100G BND MRP96', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(49, 'ALIFE LILY SOAP 30X5X100G BND MRP96', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(50, 'ALIFE SANDAL SOAP 30X5X100G BND MRP96', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(51, 'ALIFE ROSE SOAP 30X5X100G BND MRP96', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(52, 'FORTUNE MAIDA 20X500G W1', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(53, 'FORTUNE RAWA 20X500G W1', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(54, 'FORTUNE SUJI 20X500G W1', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(55, 'FORTUNE SUGAR 5 X 5KG BAG', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(56, 'FORTUNE SUGAR 25 X 1KG BAG', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(57, 'FORTUNE POHA 40X500G', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15'),
(58, 'FORTUNE INDORI POHA 40X500G', 1, '2024-03-20 07:23:15', '2024-03-20 07:23:15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_summaries`
--

CREATE TABLE `tbl_x_summaries` (
  `fld_scfid` int(11) NOT NULL,
  `fld_pid` int(11) NOT NULL,
  `fld_question` varchar(200) NOT NULL,
  `fld_placeholder` varchar(200) DEFAULT NULL,
  `fld_ans` text DEFAULT NULL,
  `fld_isnumeric` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_display_order` int(11) NOT NULL,
  `fld_type` enum('T','R','S','TA') NOT NULL DEFAULT 'T' COMMENT '''T''= Text\r\n''R''= Radio\r\n''S''= Select\r\n''TA''= Text Area',
  `fld_required` tinyint(1) DEFAULT 0 COMMENT '0=No 1=Yes',
  `fld_status` tinyint(4) NOT NULL,
  `fld_created_at` timestamp NOT NULL,
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_x_summaries`
--

INSERT INTO `tbl_x_summaries` (`fld_scfid`, `fld_pid`, `fld_question`, `fld_placeholder`, `fld_ans`, `fld_isnumeric`, `fld_display_order`, `fld_type`, `fld_required`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 1, 'Brand Present?', 'Enter brand name like tata', 'Yes<>No', 0, 1, 'R', 1, 1, '2024-04-03 17:54:52', '2024-04-03 17:54:52'),
(2, 1, 'Enter the competitor distributor name', 'Enter distributor name and address', '', 0, 2, 'TA', 0, 1, '2024-04-05 15:55:10', '2024-04-03 17:54:52'),
(3, 1, 'Select the shop size', NULL, 'Small<>Medium<>Big', 0, 3, 'S', 1, 1, '2024-04-05 15:56:10', '2024-04-03 17:54:52'),
(4, 1, 'How Many Employed in Shop?', 'Number of Employees', '', 1, 4, 'T', 1, 1, '2024-04-05 15:56:51', '2024-04-03 17:54:52'),
(5, 1, 'Shop landmark?', 'Enter the landmark area near the shop', '', 0, 5, 'T', 0, 1, '2024-04-05 15:57:35', '2024-04-03 17:54:52');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_tehsils`
--

CREATE TABLE `tbl_x_tehsils` (
  `fld_tid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_tehsil` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_tehsils`
--

INSERT INTO `tbl_x_tehsils` (`fld_tid`, `fld_state_id`, `fld_district_id`, `fld_tehsil`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 'Chopda', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 'Yawal', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 2, 'Jalgaon (Jamod)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 2, 'Sangrampur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 2, 'Shegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 'Nandura', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 3, 'Achalpur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 3, 'Chandurbazar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 4, 'Telhara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 4, 'Balapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 4, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 5, 'Sailu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 5, 'Jintur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 5, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 5, 'Gangakhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 5, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 6, 'Karmala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 6, 'Madha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 7, 'Malegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 7, 'Nandgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 8, 'Rahta', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 9, 'Junnar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 10, 'Kannad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 10, 'Soegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 10, 'Sillod', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 11, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 11, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 11, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 11, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 12, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 13, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(32, 14, 14, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(33, 14, 14, 'Walwa', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_towns`
--

CREATE TABLE `tbl_x_towns` (
  `fld_tid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_town` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_towns`
--

INSERT INTO `tbl_x_towns` (`fld_tid`, `fld_state_id`, `fld_district_id`, `fld_town`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 'Chopda', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 'Yawal', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 2, 'Jalgaon (Jamod)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 2, 'Sangrampur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 2, 'Shegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 'Nandura', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 3, 'Achalpur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 3, 'Chandurbazar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 4, 'Telhara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 4, 'Balapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 4, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 5, 'Sailu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 5, 'Jintur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 5, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 5, 'Gangakhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 5, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 6, 'Karmala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 6, 'Madha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 7, 'Malegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 7, 'Nandgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 8, 'Rahta', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 9, 'Junnar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 10, 'Kannad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 10, 'Soegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 10, 'Sillod', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 11, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 11, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 11, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 11, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 12, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 13, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(32, 14, 14, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(33, 14, 14, 'Walwa', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_towns_recce`
--

CREATE TABLE `tbl_x_towns_recce` (
  `fld_tid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_town` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_towns_recce`
--

INSERT INTO `tbl_x_towns_recce` (`fld_tid`, `fld_state_id`, `fld_district_id`, `fld_town`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 'Chopda', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 'Yawal', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 2, 'Jalgaon (Jamod)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(4, 14, 2, 'Sangrampur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(5, 14, 2, 'Shegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 'Nandura', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 3, 'Achalpur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 3, 'Chandurbazar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 4, 'Telhara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 4, 'Balapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 4, 'Akola', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 5, 'Sailu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 5, 'Jintur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 5, 'Parbhani', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 5, 'Gangakhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 5, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 6, 'Karmala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 6, 'Madha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 7, 'Malegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 7, 'Nandgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 8, 'Rahta', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 9, 'Junnar', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 10, 'Kannad', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 10, 'Soegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 10, 'Sillod', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 11, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 11, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 11, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 11, 'Wardha', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 12, 'Satara', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 13, 'Kolhapur', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(32, 14, 14, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(33, 14, 14, 'Walwa', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_villages`
--

CREATE TABLE `tbl_x_villages` (
  `fld_vid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_tehsil_id` int(11) DEFAULT NULL,
  `fld_village` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_villages`
--

INSERT INTO `tbl_x_villages` (`fld_vid`, `fld_state_id`, `fld_district_id`, `fld_tehsil_id`, `fld_village`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 1, 'Lasur', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 1, 'Chahardi', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 1, 1, 'Adwad', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(4, 14, 1, 2, 'Sakali', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(5, 14, 1, 2, 'Marul', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 3, 'Pimpalgaon Kale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 2, 4, 'Sonala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 2, 5, 'Shegaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 2, 6, 'Nimgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 2, 6, 'Wadner', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 3, 7, 'Kandali', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 3, 7, 'Pathrot', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 3, 8, 'Shirajgaon  Kasba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 3, 8, 'Khel Mahal (Karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 3, 8, 'Khel Chaudhar (karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 4, 9, 'Hiwarkhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 4, 9, 'Adgaon Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 4, 10, 'Paras', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 4, 10, 'Wadegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 4, 11, 'Borgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 5, 12, 'Walour', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 5, 13, 'Bori', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 5, 14, 'Zari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 5, 15, 'Ranisawargaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 5, 16, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 6, 17, 'Kem', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 6, 18, 'Kurdu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 6, 18, 'Bhosare', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 6, 18, 'Tembhurni', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 7, 19, 'Ravalgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 7, 19, 'Dabhadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(32, 14, 7, 20, 'Naydongari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(33, 14, 7, 20, 'Sakore', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(34, 14, 8, 21, 'Sakuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(35, 14, 8, 21, 'Puntamba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(36, 14, 8, 21, 'Wakadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(37, 14, 8, 21, 'Kolhar Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(38, 14, 8, 21, 'Loni Kh.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(39, 14, 9, 22, 'Otur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(40, 14, 9, 22, 'Ale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(41, 14, 9, 22, 'Narayangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(42, 14, 9, 22, 'Warulwadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(43, 14, 9, 22, 'Rajuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(44, 14, 10, 23, 'Shafepur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(45, 14, 10, 23, 'Deogaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(46, 14, 10, 24, 'Fardapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(47, 14, 10, 25, 'Ghatnandra', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(48, 14, 10, 25, 'Undangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(49, 14, 11, 26, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(50, 14, 11, 27, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(51, 14, 11, 28, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(52, 14, 11, 29, 'Salod (Hirapur)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(53, 14, 12, 30, 'Masur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(54, 14, 12, 30, 'Umbraj', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(55, 14, 12, 30, 'Kale', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(56, 14, 12, 30, 'Rethare bk.', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(57, 14, 13, 31, 'Pargaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(58, 14, 14, 32, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(59, 14, 14, 32, 'Mangle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(60, 14, 14, 33, 'Kasegaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(61, 14, 14, 33, 'Wategaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(62, 14, 14, 33, 'Nerle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(63, 14, 1, 1, 'hivrkhed', 1, '2024-03-20 11:05:00', '2024-03-20 11:05:00'),
(64, 14, 6, 17, 'sagrampur', 1, '2024-03-20 11:17:01', '2024-03-20 11:17:01'),
(65, 14, 6, 17, 'sonala', 1, '2024-03-21 04:25:07', '2024-03-21 04:25:07'),
(66, 14, 12, 30, 'pargaon', 1, '2024-03-21 07:23:44', '2024-03-21 07:23:44'),
(67, 14, 2, 4, 'Sangrampur', 1, '2024-03-21 09:26:51', '2024-03-21 09:26:51'),
(68, 14, 1, 1, 'adgaon bk.', 1, '2024-03-21 11:22:17', '2024-03-21 11:22:17'),
(69, 14, 1, 3, 'Dedla', 1, '2024-03-21 14:12:10', '2024-03-21 14:12:10'),
(70, 14, 4, 10, 'balapur', 1, '2024-03-22 09:53:50', '2024-03-22 09:53:50'),
(71, 14, 2, 5, 'manasgaon', 1, '2024-03-22 10:19:28', '2024-03-22 10:19:28'),
(72, 14, 3, 8, 'kharpi', 1, '2024-03-22 11:15:47', '2024-03-22 11:15:47'),
(73, 14, 2, 5, 'khandavi', 1, '2024-03-22 11:19:25', '2024-03-22 11:19:25'),
(74, 14, 3, 8, 'khapri', 1, '2024-03-22 11:23:14', '2024-03-22 11:23:14'),
(75, 14, 3, 8, 'salepur pandhri', 1, '2024-03-22 12:55:20', '2024-03-22 12:55:20'),
(76, 14, 2, 6, 'manegaon', 1, '2024-03-23 03:56:00', '2024-03-23 03:56:00'),
(77, 14, 11, 28, 'alipur', 1, '2024-03-23 05:28:42', '2024-03-23 05:28:42'),
(78, 14, 11, 28, 'alipur  hinganghat', 1, '2024-03-23 06:07:24', '2024-03-23 06:07:24'),
(79, 14, 11, 28, 'hinganghat alipur', 1, '2024-03-23 06:18:18', '2024-03-23 06:18:18'),
(80, 14, 1, 2, 'dfaghj', 1, '2024-03-28 05:30:57', '2024-03-28 05:30:57'),
(81, 14, 1, 1, 'vvhjj', 1, '2024-03-28 05:34:31', '2024-03-28 05:34:31'),
(82, 14, 1, 1, 'vbh', 1, '2024-03-28 05:45:22', '2024-03-28 05:45:22'),
(83, 14, 1, 1, 'fhgss', 1, '2024-03-28 05:52:30', '2024-03-28 05:52:30'),
(84, 14, 1, 1, 'cvhjjbji', 1, '2024-03-28 06:23:06', '2024-03-28 06:23:06'),
(85, 14, 1, 1, 'fhhhjuu', 1, '2024-03-28 06:29:30', '2024-03-28 06:29:30'),
(86, 14, 1, 1, 'gjj', 1, '2024-04-02 04:37:47', '2024-04-02 04:37:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_x_villages_mela`
--

CREATE TABLE `tbl_x_villages_mela` (
  `fld_vid` int(11) NOT NULL,
  `fld_state_id` int(11) DEFAULT NULL,
  `fld_district_id` int(11) DEFAULT NULL,
  `fld_village` varchar(255) DEFAULT NULL,
  `fld_status` tinyint(4) DEFAULT 1,
  `fld_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fld_updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_x_villages_mela`
--

INSERT INTO `tbl_x_villages_mela` (`fld_vid`, `fld_state_id`, `fld_district_id`, `fld_village`, `fld_status`, `fld_created_at`, `fld_updated_at`) VALUES
(1, 14, 1, 'Lasur', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(2, 14, 1, 'Chahardi', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(3, 14, 1, 'Adwad', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(4, 14, 1, 'Sakali', 1, '2024-03-20 07:25:22', '2024-03-20 07:25:22'),
(5, 14, 1, 'Marul', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(6, 14, 2, 'Pimpalgaon Kale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(7, 14, 2, 'Sonala', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(8, 14, 2, 'Shegaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(9, 14, 2, 'Nimgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(10, 14, 2, 'Wadner', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(11, 14, 3, 'Kandali', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(12, 14, 3, 'Pathrot', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(13, 14, 3, 'Shirajgaon  Kasba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(14, 14, 3, 'Khel Mahal (Karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(15, 14, 3, 'Khel Chaudhar (karajgaon)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(16, 14, 4, 'Hiwarkhed', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(17, 14, 4, 'Adgaon Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(18, 14, 4, 'Paras', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(19, 14, 4, 'Wadegaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(20, 14, 4, 'Borgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(21, 14, 5, 'Walour', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(22, 14, 5, 'Bori', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(23, 14, 5, 'Zari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(24, 14, 5, 'Ranisawargaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(25, 14, 5, 'Palam', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(26, 14, 6, 'Kem', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(27, 14, 6, 'Kurdu', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(28, 14, 6, 'Bhosare', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(29, 14, 6, 'Tembhurni', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(30, 14, 7, 'Ravalgaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(31, 14, 7, 'Dabhadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(32, 14, 7, 'Naydongari', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(33, 14, 7, 'Sakore', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(34, 14, 8, 'Sakuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(35, 14, 8, 'Puntamba', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(36, 14, 8, 'Wakadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(37, 14, 8, 'Kolhar Bk.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(38, 14, 8, 'Loni Kh.', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(39, 14, 9, 'Otur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(40, 14, 9, 'Ale', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(41, 14, 9, 'Narayangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(42, 14, 9, 'Warulwadi', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(43, 14, 9, 'Rajuri', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(44, 14, 10, 'Shafepur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(45, 14, 10, 'Deogaon (R)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(46, 14, 10, 'Fardapur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(47, 14, 10, 'Ghatnandra', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(48, 14, 10, 'Undangaon', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(49, 14, 11, 'Ashti', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(50, 14, 11, 'Karanja', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(51, 14, 11, 'Seloo', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(52, 14, 11, 'Salod (Hirapur)', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(53, 14, 12, 'Masur', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(54, 14, 12, 'Umbraj', 1, '2024-03-20 07:25:23', '2024-03-20 07:25:23'),
(55, 14, 12, 'Kale', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(56, 14, 12, 'Rethare bk.', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(57, 14, 13, 'Pargaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(58, 14, 14, 'Shirala', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(59, 14, 14, 'Mangle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(60, 14, 14, 'Kasegaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(61, 14, 14, 'Wategaon', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(62, 14, 14, 'Nerle', 1, '2024-03-20 07:25:24', '2024-03-20 07:25:24'),
(63, 14, 1, 'hivrkhed', 1, '2024-03-20 11:05:00', '2024-03-20 11:05:00'),
(64, 14, 6, 'sagrampur', 1, '2024-03-20 11:17:01', '2024-03-20 11:17:01'),
(65, 14, 6, 'sonala', 1, '2024-03-21 04:25:07', '2024-03-21 04:25:07'),
(66, 14, 12, 'pargaon', 1, '2024-03-21 07:23:44', '2024-03-21 07:23:44'),
(67, 14, 2, 'Sangrampur', 1, '2024-03-21 09:26:51', '2024-03-21 09:26:51'),
(68, 14, 1, 'adgaon bk.', 1, '2024-03-21 11:22:17', '2024-03-21 11:22:17'),
(69, 14, 1, 'Dedla', 1, '2024-03-21 14:12:10', '2024-03-21 14:12:10'),
(70, 14, 4, 'balapur', 1, '2024-03-22 09:53:50', '2024-03-22 09:53:50'),
(71, 14, 2, 'manasgaon', 1, '2024-03-22 10:19:28', '2024-03-22 10:19:28'),
(72, 14, 3, 'kharpi', 1, '2024-03-22 11:15:47', '2024-03-22 11:15:47'),
(73, 14, 2, 'khandavi', 1, '2024-03-22 11:19:25', '2024-03-22 11:19:25'),
(74, 14, 3, 'khapri', 1, '2024-03-22 11:23:14', '2024-03-22 11:23:14'),
(75, 14, 3, 'salepur pandhri', 1, '2024-03-22 12:55:20', '2024-03-22 12:55:20'),
(76, 14, 2, 'manegaon', 1, '2024-03-23 03:56:00', '2024-03-23 03:56:00'),
(77, 14, 11, 'alipur', 1, '2024-03-23 05:28:42', '2024-03-23 05:28:42'),
(78, 14, 11, 'alipur  hinganghat', 1, '2024-03-23 06:07:24', '2024-03-23 06:07:24'),
(79, 14, 11, 'hinganghat alipur', 1, '2024-03-23 06:18:18', '2024-03-23 06:18:18'),
(80, 14, 1, 'dfaghj', 1, '2024-03-28 05:30:57', '2024-03-28 05:30:57'),
(81, 14, 1, 'vvhjj', 1, '2024-03-28 05:34:31', '2024-03-28 05:34:31'),
(82, 14, 1, 'vbh', 1, '2024-03-28 05:45:22', '2024-03-28 05:45:22'),
(83, 14, 1, 'fhgss', 1, '2024-03-28 05:52:30', '2024-03-28 05:52:30'),
(84, 14, 1, 'cvhjjbji', 1, '2024-03-28 06:23:06', '2024-03-28 06:23:06'),
(85, 14, 1, 'fhhhjuu', 1, '2024-03-28 06:29:30', '2024-03-28 06:29:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_activity_photos`
--
ALTER TABLE `tbl_activity_photos`
  ADD PRIMARY KEY (`fld_aid`);

--
-- Indexes for table `tbl_attendances`
--
ALTER TABLE `tbl_attendances`
  ADD PRIMARY KEY (`fld_aid`);

--
-- Indexes for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  ADD PRIMARY KEY (`fld_cid`);

--
-- Indexes for table `tbl_consumers`
--
ALTER TABLE `tbl_consumers`
  ADD PRIMARY KEY (`fld_cid`);

--
-- Indexes for table `tbl_consumer_sales`
--
ALTER TABLE `tbl_consumer_sales`
  ADD PRIMARY KEY (`fld_csid`);

--
-- Indexes for table `tbl_consumer_sales_items`
--
ALTER TABLE `tbl_consumer_sales_items`
  ADD PRIMARY KEY (`fld_csiid`);

--
-- Indexes for table `tbl_mandi_consumers`
--
ALTER TABLE `tbl_mandi_consumers`
  ADD PRIMARY KEY (`fld_cid`);

--
-- Indexes for table `tbl_mandi_consumer_sales`
--
ALTER TABLE `tbl_mandi_consumer_sales`
  ADD PRIMARY KEY (`fld_mcsid`);

--
-- Indexes for table `tbl_mandi_consumer_sales_items`
--
ALTER TABLE `tbl_mandi_consumer_sales_items`
  ADD PRIMARY KEY (`fld_mcsiid`);

--
-- Indexes for table `tbl_mandi_retailers`
--
ALTER TABLE `tbl_mandi_retailers`
  ADD PRIMARY KEY (`fld_rid`);

--
-- Indexes for table `tbl_mandi_retail_sales`
--
ALTER TABLE `tbl_mandi_retail_sales`
  ADD PRIMARY KEY (`fld_rsid`);

--
-- Indexes for table `tbl_mandi_retail_sales_items`
--
ALTER TABLE `tbl_mandi_retail_sales_items`
  ADD PRIMARY KEY (`fld_mrsiid`);

--
-- Indexes for table `tbl_mandi_routes`
--
ALTER TABLE `tbl_mandi_routes`
  ADD PRIMARY KEY (`fld_rpid`);

--
-- Indexes for table `tbl_mandi_routes_historys`
--
ALTER TABLE `tbl_mandi_routes_historys`
  ADD PRIMARY KEY (`fld_mhrid`);

--
-- Indexes for table `tbl_mandi_wholesalers`
--
ALTER TABLE `tbl_mandi_wholesalers`
  ADD PRIMARY KEY (`fld_wsid`);

--
-- Indexes for table `tbl_mela`
--
ALTER TABLE `tbl_mela`
  ADD PRIMARY KEY (`fld_mid`);

--
-- Indexes for table `tbl_mela_consumers`
--
ALTER TABLE `tbl_mela_consumers`
  ADD PRIMARY KEY (`fld_mcid`);

--
-- Indexes for table `tbl_mela_images`
--
ALTER TABLE `tbl_mela_images`
  ADD PRIMARY KEY (`fld_miid`);

--
-- Indexes for table `tbl_mela_routes`
--
ALTER TABLE `tbl_mela_routes`
  ADD PRIMARY KEY (`fld_rpid`);

--
-- Indexes for table `tbl_mela_routes_historys`
--
ALTER TABLE `tbl_mela_routes_historys`
  ADD PRIMARY KEY (`fld_mhid`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`fld_pid`);

--
-- Indexes for table `tbl_products_historys`
--
ALTER TABLE `tbl_products_historys`
  ADD PRIMARY KEY (`fld_phid`);

--
-- Indexes for table `tbl_projects`
--
ALTER TABLE `tbl_projects`
  ADD PRIMARY KEY (`fld_pid`);

--
-- Indexes for table `tbl_purchases`
--
ALTER TABLE `tbl_purchases`
  ADD PRIMARY KEY (`fld_prid`);

--
-- Indexes for table `tbl_purchases_items`
--
ALTER TABLE `tbl_purchases_items`
  ADD PRIMARY KEY (`fld_piid`);

--
-- Indexes for table `tbl_recce`
--
ALTER TABLE `tbl_recce`
  ADD PRIMARY KEY (`fld_raid`);

--
-- Indexes for table `tbl_recce_images`
--
ALTER TABLE `tbl_recce_images`
  ADD PRIMARY KEY (`fld_riid`);

--
-- Indexes for table `tbl_recce_outlets`
--
ALTER TABLE `tbl_recce_outlets`
  ADD PRIMARY KEY (`fld_oid`);

--
-- Indexes for table `tbl_recce_routes`
--
ALTER TABLE `tbl_recce_routes`
  ADD PRIMARY KEY (`fld_rpid`);

--
-- Indexes for table `tbl_recce_route_historys`
--
ALTER TABLE `tbl_recce_route_historys`
  ADD PRIMARY KEY (`fld_rhid`);

--
-- Indexes for table `tbl_retailers`
--
ALTER TABLE `tbl_retailers`
  ADD PRIMARY KEY (`fld_rid`);

--
-- Indexes for table `tbl_retailers_fields`
--
ALTER TABLE `tbl_retailers_fields`
  ADD PRIMARY KEY (`fld_rfid`);

--
-- Indexes for table `tbl_retail_sales`
--
ALTER TABLE `tbl_retail_sales`
  ADD PRIMARY KEY (`fld_rsid`);

--
-- Indexes for table `tbl_retail_sales_items`
--
ALTER TABLE `tbl_retail_sales_items`
  ADD PRIMARY KEY (`fld_rsiid`);

--
-- Indexes for table `tbl_route_plans`
--
ALTER TABLE `tbl_route_plans`
  ADD PRIMARY KEY (`fld_rpid`);

--
-- Indexes for table `tbl_route_plans_historys`
--
ALTER TABLE `tbl_route_plans_historys`
  ADD PRIMARY KEY (`fld_rphid`);

--
-- Indexes for table `tbl_stockists`
--
ALTER TABLE `tbl_stockists`
  ADD PRIMARY KEY (`fld_sid`),
  ADD UNIQUE KEY `fld_number` (`fld_number`);

--
-- Indexes for table `tbl_summaries`
--
ALTER TABLE `tbl_summaries`
  ADD PRIMARY KEY (`fld_sid`);

--
-- Indexes for table `tbl_tokens`
--
ALTER TABLE `tbl_tokens`
  ADD PRIMARY KEY (`fld_tid`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`fld_uid`),
  ADD UNIQUE KEY `fld_name` (`fld_name`);

--
-- Indexes for table `tbl_voice_messages`
--
ALTER TABLE `tbl_voice_messages`
  ADD PRIMARY KEY (`fld_vid`);

--
-- Indexes for table `tbl_x_districts`
--
ALTER TABLE `tbl_x_districts`
  ADD PRIMARY KEY (`fld_did`);

--
-- Indexes for table `tbl_x_districts_mandi`
--
ALTER TABLE `tbl_x_districts_mandi`
  ADD PRIMARY KEY (`fld_did`);

--
-- Indexes for table `tbl_x_districts_mela`
--
ALTER TABLE `tbl_x_districts_mela`
  ADD PRIMARY KEY (`fld_did`);

--
-- Indexes for table `tbl_x_districts_recce`
--
ALTER TABLE `tbl_x_districts_recce`
  ADD PRIMARY KEY (`fld_did`);

--
-- Indexes for table `tbl_x_fields`
--
ALTER TABLE `tbl_x_fields`
  ADD PRIMARY KEY (`fld_cfid`);

--
-- Indexes for table `tbl_x_mandis`
--
ALTER TABLE `tbl_x_mandis`
  ADD PRIMARY KEY (`fld_mid`);

--
-- Indexes for table `tbl_x_ptypes`
--
ALTER TABLE `tbl_x_ptypes`
  ADD PRIMARY KEY (`fld_ptid`);

--
-- Indexes for table `tbl_x_recce_types`
--
ALTER TABLE `tbl_x_recce_types`
  ADD PRIMARY KEY (`fld_rtid`);

--
-- Indexes for table `tbl_x_states`
--
ALTER TABLE `tbl_x_states`
  ADD PRIMARY KEY (`fld_sid`);

--
-- Indexes for table `tbl_x_summaries`
--
ALTER TABLE `tbl_x_summaries`
  ADD PRIMARY KEY (`fld_scfid`);

--
-- Indexes for table `tbl_x_tehsils`
--
ALTER TABLE `tbl_x_tehsils`
  ADD PRIMARY KEY (`fld_tid`);

--
-- Indexes for table `tbl_x_towns`
--
ALTER TABLE `tbl_x_towns`
  ADD PRIMARY KEY (`fld_tid`);

--
-- Indexes for table `tbl_x_towns_recce`
--
ALTER TABLE `tbl_x_towns_recce`
  ADD PRIMARY KEY (`fld_tid`);

--
-- Indexes for table `tbl_x_villages`
--
ALTER TABLE `tbl_x_villages`
  ADD PRIMARY KEY (`fld_vid`);

--
-- Indexes for table `tbl_x_villages_mela`
--
ALTER TABLE `tbl_x_villages_mela`
  ADD PRIMARY KEY (`fld_vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_activity_photos`
--
ALTER TABLE `tbl_activity_photos`
  MODIFY `fld_aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_attendances`
--
ALTER TABLE `tbl_attendances`
  MODIFY `fld_aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_clients`
--
ALTER TABLE `tbl_clients`
  MODIFY `fld_cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_consumers`
--
ALTER TABLE `tbl_consumers`
  MODIFY `fld_cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_consumer_sales`
--
ALTER TABLE `tbl_consumer_sales`
  MODIFY `fld_csid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_consumer_sales_items`
--
ALTER TABLE `tbl_consumer_sales_items`
  MODIFY `fld_csiid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mandi_consumers`
--
ALTER TABLE `tbl_mandi_consumers`
  MODIFY `fld_cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mandi_consumer_sales`
--
ALTER TABLE `tbl_mandi_consumer_sales`
  MODIFY `fld_mcsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_mandi_consumer_sales_items`
--
ALTER TABLE `tbl_mandi_consumer_sales_items`
  MODIFY `fld_mcsiid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_mandi_retailers`
--
ALTER TABLE `tbl_mandi_retailers`
  MODIFY `fld_rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mandi_retail_sales`
--
ALTER TABLE `tbl_mandi_retail_sales`
  MODIFY `fld_rsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_mandi_retail_sales_items`
--
ALTER TABLE `tbl_mandi_retail_sales_items`
  MODIFY `fld_mrsiid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_mandi_routes`
--
ALTER TABLE `tbl_mandi_routes`
  MODIFY `fld_rpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `tbl_mandi_routes_historys`
--
ALTER TABLE `tbl_mandi_routes_historys`
  MODIFY `fld_mhrid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_mandi_wholesalers`
--
ALTER TABLE `tbl_mandi_wholesalers`
  MODIFY `fld_wsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_mela`
--
ALTER TABLE `tbl_mela`
  MODIFY `fld_mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mela_consumers`
--
ALTER TABLE `tbl_mela_consumers`
  MODIFY `fld_mcid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mela_images`
--
ALTER TABLE `tbl_mela_images`
  MODIFY `fld_miid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_mela_routes`
--
ALTER TABLE `tbl_mela_routes`
  MODIFY `fld_rpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `tbl_mela_routes_historys`
--
ALTER TABLE `tbl_mela_routes_historys`
  MODIFY `fld_mhid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `fld_pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_products_historys`
--
ALTER TABLE `tbl_products_historys`
  MODIFY `fld_phid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_projects`
--
ALTER TABLE `tbl_projects`
  MODIFY `fld_pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_purchases`
--
ALTER TABLE `tbl_purchases`
  MODIFY `fld_prid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_purchases_items`
--
ALTER TABLE `tbl_purchases_items`
  MODIFY `fld_piid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_recce`
--
ALTER TABLE `tbl_recce`
  MODIFY `fld_raid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_recce_images`
--
ALTER TABLE `tbl_recce_images`
  MODIFY `fld_riid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_recce_outlets`
--
ALTER TABLE `tbl_recce_outlets`
  MODIFY `fld_oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_recce_routes`
--
ALTER TABLE `tbl_recce_routes`
  MODIFY `fld_rpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `tbl_recce_route_historys`
--
ALTER TABLE `tbl_recce_route_historys`
  MODIFY `fld_rhid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_retailers`
--
ALTER TABLE `tbl_retailers`
  MODIFY `fld_rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_retailers_fields`
--
ALTER TABLE `tbl_retailers_fields`
  MODIFY `fld_rfid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_retail_sales`
--
ALTER TABLE `tbl_retail_sales`
  MODIFY `fld_rsid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_retail_sales_items`
--
ALTER TABLE `tbl_retail_sales_items`
  MODIFY `fld_rsiid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_route_plans`
--
ALTER TABLE `tbl_route_plans`
  MODIFY `fld_rpid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `tbl_route_plans_historys`
--
ALTER TABLE `tbl_route_plans_historys`
  MODIFY `fld_rphid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_stockists`
--
ALTER TABLE `tbl_stockists`
  MODIFY `fld_sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_summaries`
--
ALTER TABLE `tbl_summaries`
  MODIFY `fld_sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_tokens`
--
ALTER TABLE `tbl_tokens`
  MODIFY `fld_tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `fld_uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_voice_messages`
--
ALTER TABLE `tbl_voice_messages`
  MODIFY `fld_vid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_x_districts`
--
ALTER TABLE `tbl_x_districts`
  MODIFY `fld_did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_x_districts_mandi`
--
ALTER TABLE `tbl_x_districts_mandi`
  MODIFY `fld_did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_x_districts_mela`
--
ALTER TABLE `tbl_x_districts_mela`
  MODIFY `fld_did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_x_districts_recce`
--
ALTER TABLE `tbl_x_districts_recce`
  MODIFY `fld_did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_x_fields`
--
ALTER TABLE `tbl_x_fields`
  MODIFY `fld_cfid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_x_mandis`
--
ALTER TABLE `tbl_x_mandis`
  MODIFY `fld_mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `tbl_x_ptypes`
--
ALTER TABLE `tbl_x_ptypes`
  MODIFY `fld_ptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_x_recce_types`
--
ALTER TABLE `tbl_x_recce_types`
  MODIFY `fld_rtid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_x_states`
--
ALTER TABLE `tbl_x_states`
  MODIFY `fld_sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `tbl_x_summaries`
--
ALTER TABLE `tbl_x_summaries`
  MODIFY `fld_scfid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_x_tehsils`
--
ALTER TABLE `tbl_x_tehsils`
  MODIFY `fld_tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_x_towns`
--
ALTER TABLE `tbl_x_towns`
  MODIFY `fld_tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_x_towns_recce`
--
ALTER TABLE `tbl_x_towns_recce`
  MODIFY `fld_tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tbl_x_villages`
--
ALTER TABLE `tbl_x_villages`
  MODIFY `fld_vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `tbl_x_villages_mela`
--
ALTER TABLE `tbl_x_villages_mela`
  MODIFY `fld_vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

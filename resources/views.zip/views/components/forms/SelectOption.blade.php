<select name="project_id" class="form-control bg-light border-light flatpickr-input">
    <option value="">@lang('Project') </option>
</select>
